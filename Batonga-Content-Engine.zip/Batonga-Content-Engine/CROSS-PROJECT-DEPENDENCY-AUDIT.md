# Cross-project dependency audit

Source checkpoint: `a91b9da522d38e8b8b1af651b1050c29d1a91484`

## Batonga imports outside `packages/content`

The accepted content package was inspected before extraction. Its external dependencies are classified below.

| Dependency                        | Classification                            | Standalone treatment                                              |
| --------------------------------- | ----------------------------------------- | ----------------------------------------------------------------- |
| React / ReactDOM                  | A — generic technical dependency          | Retained for `LessonPlayer`, block renderers, tests, and preview  |
| Zod                               | A — generic technical dependency          | Retained for schema validation                                    |
| Node.js built-ins                 | A — generic technical dependency          | Used by validators, tests, and the accepted development demo      |
| TypeScript, tsx, Vitest, Prettier | C — development toolchain                 | Retained only as development dependencies                         |
| `components/dev/content-demo.tsx` | Batonga-only accepted integration fixture | Retained because the accepted content integration test imports it |

The standalone preview imports only the accepted `@core/content` API and a local asset URL adapter. It does not import application code from the source repository.

## Excluded source-project systems

The extraction excludes all source application routes, festival pages and components, registration and account flows, band/community/application features, admin and RBAC logic, Prisma/database code, Better Auth, APIs, branding, environment configuration, and festival tests. It also excludes the original root package configuration and lockfile. The standalone package manifest and lockfile are generated specifically for Batonga.

## Result

Floating Music Festival runtime, development, and package dependencies: **0**.
