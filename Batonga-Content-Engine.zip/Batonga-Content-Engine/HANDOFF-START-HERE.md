# Batonga standalone handoff

## Deliverable

**Batonga Content Digitalisation & Lesson Engine**  
Dev A status: **COMPLETE**  
Source checkpoint: `a91b9da522d38e8b8b1af651b1050c29d1a91484`  
Schema: **v1.0.2**

## Accepted inventory

- Corpus: 56 literacy lessons, 10 numeracy units, 8 front-matter items, and 1 literacy reference material.
- Assets: 24 illustrations and 44 cursive glyphs; 68/68 available.
- ReviewIssues: 44/44 `confirmed_source`; 0 pending.
- Original acceptance suite in the source repository: 281/281 PASS. This standalone project intentionally excludes unrelated Floating Music Festival tests and runs the Batonga package's own test suite.

The original textbook PDF is **not required at runtime**. Source page references remain as provenance.

## Start the Batonga-only preview

```sh
cd ~/Desktop/Batonga-Content-Engine
npm install
npm run dev
```

Open <http://localhost:5173/>.

The preview lets you inspect all literacy lessons with Previous/Next navigation, numeracy units 0–9, all front matter, the alphabet chart, and all 68 production assets. Lessons render through the accepted `LessonPlayer`; other content uses the accepted repository and block renderer architecture.

## Read next

- `packages/content/README.md`
- `packages/content/HANDOFF.md`
- `packages/content/DELIVERY_REPORT.md`
- `CROSS-PROJECT-DEPENDENCY-AUDIT.md`

## Downstream integration boundaries

1. Map package-relative production asset paths to browser URLs. The standalone preview's adapter is a development example.
2. Implement the `AudioRef` recorded-audio/TTS runtime in the consuming product. Audio production is outside this handoff.
3. Do not silently modify frozen source-faithful content. Preserve visible source anomalies and the accepted ReviewIssue decisions.
