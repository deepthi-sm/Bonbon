# Batonga Content Engine

This is the standalone handoff for the Batonga Content Digitalisation & Lesson Engine. It contains the accepted content package, its production assets, validators, tests, durable QA evidence, and a Batonga-only browser preview.

The project was extracted from source checkpoint `a91b9da522d38e8b8b1af651b1050c29d1a91484`. The accepted files under `packages/content/` and `components/dev/content-demo.tsx` are preserved from that checkpoint. The root build files and `preview/` application are small standalone scaffolding created for this handoff.

## Quick start

Requirements: Node.js 22.12 or later and npm.

```sh
npm install
npm run dev
```

Open <http://localhost:5173/>.

## Available commands

```sh
npm run validate-content
npm run validate-content:full
npm run validate-assets
npm test
npm run typecheck
npm run format:check
npm run build
```

`npm run check` runs all of these checks in sequence.

## Package contents

- 56 literacy lessons
- 10 numeracy units (0–9)
- 8 front-matter items
- 1 literacy reference material / alphabet chart
- 24 illustrations and 44 cursive glyphs (68/68 available)
- 44 confirmed-source ReviewIssues and 0 pending issues
- schema v1.0.2, content repository, renderers, validation, tests, and retained QA evidence

The original textbook PDF is not needed at runtime. Its filename and page references may appear in provenance and historical audit records.

## Integration boundaries

Downstream applications must map package-relative production asset paths to browser URLs and implement the existing `AudioRef` contract using recorded audio or TTS. Do not silently alter frozen source-faithful content. See `packages/content/HANDOFF.md` and `packages/content/DELIVERY_REPORT.md` for the accepted package contract and delivery evidence.
