import { readFileSync } from 'node:fs';
import path from 'node:path';

import {
  BlockRenderer,
  LessonPlayer,
  type ContentAsset,
  contentAssets,
  contentRepository,
} from '@core/content';

function requireFixture<T>(value: T | undefined, name: string): T {
  if (!value) {
    throw new Error(`Missing Batonga content fixture: ${name}`);
  }

  return value;
}

export function ContentDemo() {
  const previewAssets: ContentAsset[] = contentAssets.map((asset) => {
    if (asset.status !== 'available' || !asset.path) return asset;
    const bytes = readFileSync(
      path.join(process.cwd(), 'packages/content', asset.path),
    );
    const extension = path.extname(asset.path).slice(1).toLowerCase();
    const mimeType =
      extension === 'svg' ? 'image/svg+xml' : `image/${extension}`;
    return {
      ...asset,
      path: `data:${mimeType};base64,${bytes.toString('base64')}`,
    };
  });
  const lesson01 = requireFixture(
    contentRepository.getLessonByNumber(1),
    'Lesson 01',
  );
  const lesson06 = requireFixture(
    contentRepository.getLessonByNumber(6),
    'Lesson 06',
  );
  const lesson42 = requireFixture(
    contentRepository.getLessonByNumber(42),
    'Lesson 42',
  );
  const lesson56 = requireFixture(
    contentRepository.getLessonByNumber(56),
    'Lesson 56',
  );
  const unit0 = requireFixture(
    contentRepository.getNumeracyUnit(0),
    'Numeracy Unit 0',
  );
  const unit9 = requireFixture(
    contentRepository.getNumeracyUnit(9),
    'Numeracy Unit 9',
  );

  return (
    <section className="space-y-12">
      <header className="space-y-3">
        <p className="text-sm tracking-[0.2em] text-[var(--muted)] uppercase">
          Internal development route
        </p>
        <h1 className="text-3xl font-semibold">Batonga Content Engine</h1>
        <p className="max-w-3xl text-[var(--muted)]">
          All examples below are loaded through the read-only contentRepository.
          Lessons 01 and 06 display the Phase 3A source-asset pilot; Lesson 42
          demonstrates unlabelled dialogue; Lesson 56 confirms late-corpus
          retrieval.
        </p>
      </header>

      <div className="grid gap-8 lg:grid-cols-2">
        <div className="rounded-2xl bg-[var(--panel)] p-6 shadow-sm">
          <LessonPlayer lesson={lesson01} assets={previewAssets} />
        </div>
        <div className="rounded-2xl bg-[var(--panel)] p-6 shadow-sm">
          <LessonPlayer lesson={lesson06} assets={previewAssets} />
        </div>
        <div className="rounded-2xl bg-[var(--panel)] p-6 shadow-sm">
          <LessonPlayer lesson={lesson42} assets={previewAssets} />
        </div>
        <div className="rounded-2xl bg-[var(--panel)] p-6 shadow-sm lg:col-span-2">
          <LessonPlayer lesson={lesson56} assets={previewAssets} />
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        {[unit0, unit9].map((unit) => (
          <article
            key={unit.id}
            className="space-y-5 rounded-2xl bg-[var(--panel)] p-6 shadow-sm"
            data-numeracy-unit={unit.number}
          >
            <header>
              <p className="text-sm text-[var(--muted)]">
                Numeracy Unit {unit.number}
              </p>
              <h2 className="text-2xl font-semibold">
                {unit.numeral} · {unit.word}
              </h2>
            </header>
            {unit.blocks.map((block) => (
              <BlockRenderer
                key={block.id}
                block={block}
                assets={previewAssets}
              />
            ))}
          </article>
        ))}
      </div>
    </section>
  );
}
