# Batonga Content Engine — Final Dev A Delivery Report

## Acceptance result

The Dev A package is complete under **Batonga Content Schema v1.0.2**. The source-supported corpus, production assets, review adjudications, repository API, renderers, validation, tests, and audit evidence are ready for downstream integration.

## Delivered corpus

| Domain                       | Delivered |
| ---------------------------- | --------: |
| Literacy lessons             |     56/56 |
| Numeracy units               |     10/10 |
| Front-matter items           |       8/8 |
| Literacy reference materials |       1/1 |
| Registered/available assets  |     68/68 |
| Illustrations                |        24 |
| Cursive glyphs               |        44 |
| ReviewIssues confirmed       |     44/44 |
| Pending ReviewIssues         |         0 |

All 68 semantic asset references resolve to unique registry records and non-empty package-relative production files. Production orphan count is zero. Visual QA passed for all 68 assets.

## Portability and runtime boundary

Production code and content contain no machine-specific runtime dependency. The source-document basename is retained as provenance; absolute paths in historical QA reports and extraction instructions remain developer evidence. The original PDF is not needed to install, validate, test, build, load the repository, render the player, or resolve production files.

Registry paths are relative to `packages/content`. A browser application must publish/import those files and pass URL-mapped asset records to `LessonPlayer` or `BlockRenderer`. The renderers already accept this injected collection, so no raw JSON or PDF-layout knowledge is needed.

Review records are isolated in an internal review-data module. Heavy QA material—source crops, processed previews, contact sheets, extraction manifests, and reports—is never loaded by the production repository/player path.

## Content integrity

Phase 3C did not change lesson, numeracy, front-matter, or alphabet semantic content; targets or ordering; Phase 2D decisions; registry semantics; or production asset bytes. A SHA-256 baseline covers all 130 frozen semantic/review/asset files and is stored in `review/phase-3c/frozen-content-hashes.json`.

The source-fidelity policy remains: preserve visible spelling, punctuation, capitalization, accents, ordering, print/cursive differences, and anomalies; never silently correct the source.

## Public API and developer route

The `@core/content` entry point exposes the repository, repository factory, players/renderers, production asset records, schemas, and public types. Consumers retrieve literacy, numeracy, front matter, and reference material through repository methods.

`/dev/content` resolves package assets into data URLs for representative content. It remains useful during development and returns 404 in production.

## Workspace and intended commit

The pre-audit workspace contained 372 untracked files. The Phase 3C inventory classifies every one in `review/phase-3c/untracked-file-audit.json`. Required production/source/test/documentation files and durable QA evidence belong in the intended commit. The 55 temporary PDF renders and one Python bytecode cache do not.

`.gitignore` now excludes only safe local scratch classes: `tmp/`, `__pycache__/`, and `*.py[cod]`. Production asset trees are not ignored.

See `review/phase-3c/INTENDED-COMMIT-MANIFEST.md` for the proposed commit boundary. No files were staged, committed, pushed, or deleted.

## Remaining downstream work

The application must map package asset files to deployed URLs, implement product UI and state, and connect the existing audio keys to recordings or TTS. These are integration responsibilities outside Dev A's content scope; they do not block package acceptance.

The full Phase 3C gate evidence and portability simulation are recorded in `review/phase-3c/FINAL-DEV-A-ACCEPTANCE-REPORT.md`.
