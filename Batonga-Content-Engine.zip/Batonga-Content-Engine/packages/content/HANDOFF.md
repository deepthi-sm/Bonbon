# Batonga Content Engine — Developer Handoff

## Delivered contract

Dev A delivers **Batonga Content Schema v1.0.2** and a complete, validated, read-only corpus:

- 56 literacy lessons;
- 10 numeracy units (0–9);
- 8 front-matter items;
- 1 standalone alphabet reference material;
- 68 available source-extracted assets: 24 illustrations and 44 cursive glyphs;
- 44 ReviewIssues, all `confirmed_source`, with 0 pending.

The 20 Phase 2D human decisions and 6 Phase 3A pilot assets remain unchanged. All 68 assets passed visual QA and file/hash integrity checks.

## Integration API

Import from `@core/content`:

```ts
import {
  BlockRenderer,
  LessonPlayer,
  contentAssets,
  contentRepository,
  createContentRepository,
  type AudioRef,
  type ContentAsset,
  type Lesson,
  type NumeracyUnit,
  type ReviewIssue,
} from '@core/content';
```

Application code should not import raw JSON, `src/` internals, review manifests, or source crops.

```tsx
const lesson = contentRepository.getLessonByNumber(42);
return lesson ? <LessonPlayer lesson={lesson} assets={webAssets} /> : null;
```

`getPreviousLesson` and `getNextLesson` traverse Lessons 1–56. Use `getNumeracyUnit`, `getFrontMatter`, and `getLiteracyReferenceMaterial` for their separate domains. Repository results are parsed, immutable, and independent of physical PDF layout.

## Asset integration

Registry paths are portable package-relative filesystem paths rooted at `packages/content`, for example `assets/glyphs/lesson-02-lowercase-a.png`. They are not guaranteed browser URLs.

The application asset pipeline must publish or import the files, create a collection that preserves each asset ID and replaces `path` with its deployable URL, then pass that collection to `LessonPlayer` or `BlockRenderer`. This is the only remaining asset integration step. The renderer performs ID lookup; semantic blocks never contain local absolute paths.

The internal `/dev/content` route demonstrates server-side resolution by reading package files and supplying data URLs. It is available only during development and returns 404 in production.

## Audio boundary

The content package owns `AudioRef.key`, exact `fallbackText`, and where audio hooks appear. The application or audio subsystem owns recordings/TTS, key-to-file resolution, caching, delivery, playback controls, and failure handling. No audio binary is required for content validity.

## Source-fidelity contract

- Treat visual inspection of the source PDF as authoritative.
- Preserve spelling, accents, case, punctuation, source order, and real print/cursive differences.
- Keep `pdfPages` separate from `printedPages`.
- Do not infer speakers for unlabelled dialogue.
- Preserve visible anomalies and document them; do not silently correct them.
- Preserve duplicate physical pages in provenance while storing duplicate semantic material once.
- Do not replace extracted handwriting with fonts, redrawings, or generated forms.

Representative preserved cases include Lesson 08 (`tite` / `titi`), Lesson 09's distinct print/cursive vocabulary, Lesson 21 (`la gardien de la gare.`), Lesson 31 (`tein` / `ein` and `route Il`), Lesson 40's isolated cursive `un` and terminal `deux`, duplicate source pages for Lessons 49 and 56, Lesson 53's distinct print/cursive lists, and back-cover `pourvoir`.

## Production and QA separation

Production consists of structured content, schemas/types, repository/player code, and `assets/illustrations` plus `assets/glyphs`. `review/issues.json` is authoring/validation data and is loaded only by the dedicated internal review module and validators. Phase 2D/3 manifests, source crops, QA previews, contact sheets, extraction scripts, and reports are evidence; the application does not require them.

The original PDF is source authority only. No validation, test, build, repository lookup, player render, or asset resolution step depends on its local path.

## Validation

```bash
npm run validate-content
CONTENT_VALIDATION_MODE=full npm run validate-content
node packages/content/review/phase-3/verify-phase-3b.cjs
npm run typecheck
npm run lint
npm test
npm run format:check
npm run build
git diff --check
```

## Ownership after handoff

- **Dev A content package:** maintain source-faithful content, schemas, production assets, repository/renderers, validation, and audit evidence.
- **Application:** map package asset paths to deployed URLs, build learner-facing UI, and own routing/state.
- **Audio:** produce and deliver audio for the existing keys.
- **Backend/product:** own progress, mastery, authentication, authorization, submissions, and analytics.

Do not change transcription to satisfy application preferences. Add presentation behavior outside the semantic records, and route suspected source corrections through explicit review.
