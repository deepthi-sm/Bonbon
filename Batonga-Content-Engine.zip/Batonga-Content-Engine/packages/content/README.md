# Batonga Content & Lesson Engine

Schema contract: **Batonga Content Schema v1.0.2**.

The package is the read-only content boundary for the Batonga syllabary:

```text
source PDF
  -> visually reviewed structured JSON
  -> Zod validation and cross-record invariants
  -> read-only contentRepository
  -> LessonPlayer / BlockRenderer
  -> consuming application
```

## Accepted delivery state

- Literacy: **56/56 lessons**.
- Numeracy: **10/10 units** (0–9).
- Front matter: **8/8 semantic items**.
- Literacy reference materials: **1 alphabet chart**.
- Assets: **68/68 available and visually approved**: 24 illustrations and 44 cursive glyphs.
- Review records: **44/44 `confirmed_source`**, with 0 pending.
- Normal, full-corpus, and asset-integrity validation: **pass**.

Audio references are stable content hooks. Recordings, TTS, delivery, caching, and playback remain owned by the consuming application or audio service.

## Public API

Application code imports from `@core/content`; it does not import raw JSON or package internals.

```tsx
import {
  LessonPlayer,
  contentAssets,
  contentRepository,
  type ContentAsset,
} from '@core/content';

const lesson = contentRepository.getLessonByNumber(42);

export function Example({ assets }: { assets: readonly ContentAsset[] }) {
  return lesson ? <LessonPlayer lesson={lesson} assets={assets} /> : null;
}
```

The public entry point exports `contentRepository`, `createContentRepository`, `LessonPlayer`, `BlockRenderer`, `contentAssets`, the persisted schemas, and their public types, including `Lesson`, `NumeracyUnit`, `AudioRef`, `ContentAsset`, and `ReviewIssue`.

The repository provides immutable access to:

```ts
contentRepository.getBook();
contentRepository.getFrontMatter();
contentRepository.getLiteracySections();
contentRepository.getLessons();
contentRepository.getLessonByNumber(1);
contentRepository.getPreviousLesson('lesson-02');
contentRepository.getNextLesson('lesson-02');
contentRepository.getNumeracyUnits();
contentRepository.getNumeracyUnit(9);
contentRepository.getLiteracyReferenceMaterials();
contentRepository.getLiteracyReferenceMaterial('alphabet-chart');
```

Front matter, reference materials, and numeracy remain separate domains. Production consumers do not need to know physical PDF page layout.

## Production asset paths

Each available asset has a package-relative path such as `assets/illustrations/lesson-01.png`. The path identifies a file under `packages/content`; it is portable across machines and is not automatically a browser URL.

The integrating application must copy/import these files through its asset pipeline and pass records with deployable URLs to `LessonPlayer` or `BlockRenderer` through their `assets` prop. The renderers resolve block asset IDs against that supplied collection. The development route demonstrates one server-side adapter by converting package files to data URLs.

All 68 semantic references resolve to registered, non-empty files under `packages/content/assets`. There are no dangling references, missing files, or production orphan images.

## Development QA route

`/dev/content` loads representative early, middle, and late lessons plus Numeracy Units 0 and 9 through `contentRepository`. It maps package-relative files to previewable data URLs and returns 404 when `NODE_ENV=production`.

## Directory contract

- `content/`: production structured content and the asset registry.
- `assets/illustrations/` and `assets/glyphs/`: production PNG files.
- `src/schema/`: Schema v1.0.2 contracts and public types.
- `src/repository/`: immutable retrieval and navigation.
- `src/player/`: generic renderer dispatch.
- `review/issues.json`: validated source-review records used by authoring and validation, separated from production content loading.
- `review/phase-*`: audit reports, manifests, contact sheets, and source/processed comparisons. Applications do not need these files at runtime.
- `inventory/literacy-source-map.json`: source mapping and digitisation state.
- `SCHEMA_GAPS.md`: historical schema-gap decisions.

## Source-fidelity rules

1. Use visual inspection of the source PDF as authority.
2. Preserve spelling, capitalization, punctuation, accents, ordering, and genuine print/cursive differences.
3. Keep lesson titles separate from learning targets.
4. Record physical PDF pages and printed textbook pages separately. `pdfPages` is required and non-empty; `printedPages` is required and may be empty only when the physical page is confirmed unnumbered.
5. Preserve meaningful source order.
6. Do not infer speakers for visually unlabelled dialogue.
7. Preserve visible source anomalies and record them as ReviewIssues; never silently correct them.
8. Use source-extracted illustrations and handwriting. Do not substitute fonts, redraw forms, or fabricate assets.
9. Use stable lowercase audio keys and exact semantic fallback text.
10. Keep numeracy in `NumeracyUnit`; never encode it as an additional literacy lesson.

## Validation

Run from the repository root:

```bash
npm run validate-content
CONTENT_VALIDATION_MODE=full npm run validate-content
node packages/content/review/phase-3/verify-phase-3b.cjs
npm run typecheck
npm run lint
npm test
npm run format:check
npm run build
git diff --check
```

The asset-integrity verifier checks availability, paths, file sizes, hashes, visual-QA status, Phase 2D adjudication immutability, and Phase 3A pilot immutability.

## Ownership boundary

Dev A owns the static, source-faithful content package: schemas, validated content, asset registry/files, repository, renderers, tests, and audit evidence. Application teams own routes and product UI, browser asset publishing, audio implementation, learner state, authentication, authorization, analytics, submissions, generated exercises, and handwriting scoring.
