# Batonga Content Engine — Schema Gaps

## SG-001: unnumbered source pages — resolved in v1.0.2

### Historical finding

Schema v1.0.1 required every `SourceRef` to contain at least one positive `printedPages` value. The source cover, title page, Préface, printing note, and Angélique Kidjo/contact back cover have physical PDF page locations but no printed textbook page numbers. Inventing zero or another page number would have violated source fidelity, so Phase 2B left those items unpersisted.

### Resolution

Schema v1.0.2 keeps `pdfPages` mandatory and non-empty and keeps `printedPages` mandatory. It permits an empty `printedPages` array with one precise meaning: the cited physical PDF page is confirmed to be unnumbered.

The following remain invalid:

- missing `pdfPages`;
- empty `pdfPages`;
- missing `printedPages`;
- `0`, `null`, fabricated, or inferred printed page numbers.

The source-supported semantic front matter now validates with exact physical PDF provenance, so the Phase 2B front-matter provenance blocker is resolved.

## SG-002: standalone alphabet-chart placement — resolved in v1.0.2

### Historical finding

The alphabet chart on PDF page 5 / printed page 4 is pedagogical literacy content, but it is not a numbered lesson, numeracy, or ordinary front matter. Phase 2B did not force it into an inaccurate content type.

### Resolution

Schema v1.0.2 adds `LiteracyCurriculum.referenceMaterials`. The chart is represented as an `alphabet_chart` reference material containing 26 source-ordered entries. Each entry records its lowercase and uppercase grapheme, `print` and `cursive` representations, and the source's explicit `vowel` or `consonant` classification.

The chart is not Lesson 00, Lesson 57, part of Lesson 01, front matter, or numeracy. Repository access is provided without routing it through `LessonPlayer`.

## Open schema gaps

No open schema gap was identified during Phase 2C. Visual asset extraction, audio production, ReviewIssue decisions, and learner/application state remain separate implementation scopes rather than schema gaps.
