# Content assets

Reviewed production extractions belong under `illustrations/` or `glyphs/` and must be registered in `content/assets.json`. Source-review crops and QA previews remain under `review/phase-3/` and are not application assets.

Only technical processing of source material is allowed: crop, background cleanup, contrast adjustment, and format conversion. Do not redraw, replace, or semantically alter textbook illustrations or glyphs.

Phase 3A contains six visually verified pilot assets from Lessons 01 and 06. Phase 3B extracted and visually verified the remaining 62 registered assets under the same provenance and QA standard. All 68 registry entries now resolve to production files. See `review/phase-3/extraction-specification.md` and `review/phase-3/qa-manifest.json` for the governing standard and complete audit record.
