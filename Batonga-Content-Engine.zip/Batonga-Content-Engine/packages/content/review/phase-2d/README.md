# Phase 2D review support

This directory contains non-production QA artifacts for human ReviewIssue adjudication.

- `audit.json` groups and classifies all 44 production ReviewIssues.
- `build-audit.cjs` deterministically rebuilds the audit and batch manifests from production data without changing it.
- `batch-01/manifest.json` records the seven adjudicated issues from the first human review batch.
- `batch-02/manifest.json` records the seven adjudicated issues from the second human review batch.
- `batch-03/manifest.json` records the six adjudicated issues from the third human review batch.
- Each batch's `crops/` directory contains focused, unaltered source-page crops used only as visual evidence.

The audit generator and visual-support files do not alter production content. All 20 human-decision issues have been adjudicated; the remaining 24 records are asset-extraction backlog for Phase 3.
