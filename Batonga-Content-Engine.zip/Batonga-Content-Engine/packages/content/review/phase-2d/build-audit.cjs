/* eslint-disable @typescript-eslint/no-require-imports */

const fs = require('node:fs');
const path = require('node:path');

const reviewRoot = __dirname;
const packageRoot = path.resolve(reviewRoot, '../..');

function readJson(relativePath) {
  return JSON.parse(
    fs.readFileSync(path.join(packageRoot, relativePath), 'utf8'),
  );
}

const issues = readJson('review/issues.json');
const frontMatter = readJson('content/front-matter/front-matter.json').items;
const referenceMaterials = readJson(
  'content/literacy/reference-materials.json',
);
const numeracy = readJson('content/numeracy/units.json').units;
const lessons = fs
  .readdirSync(path.join(packageRoot, 'content/literacy'))
  .filter((filename) => /^lesson-\d+\.json$/.test(filename))
  .map((filename) => readJson(`content/literacy/${filename}`));

const records = [
  ...lessons.map((data) => ({
    kind: 'lesson',
    id: data.id,
    label: `Lesson ${String(data.lessonNumber).padStart(2, '0')}`,
    data,
  })),
  ...frontMatter.map((data) => ({
    kind: 'front_matter',
    id: data.id,
    label: `Front matter: ${data.id}`,
    data,
  })),
  ...referenceMaterials.map((data) => ({
    kind: 'reference_material',
    id: data.id,
    label: `Reference material: ${data.id}`,
    data,
  })),
  ...numeracy.map((data) => ({
    kind: 'numeracy',
    id: data.id,
    label: `Numeracy Unit ${data.number}`,
    data,
  })),
];

const humanIssueDetails = {
  'lesson-08-review-1': {
    currentStoredContent:
      'Print constructed-word sequence starts with “tite”; the corresponding cursive sequence starts with “titi”. Both are stored separately.',
    proposedReviewAction:
      'Visually confirm both readings and whether separate print/cursive sequences are the correct semantic structure.',
  },
  'lesson-09-review-1': {
    currentStoredContent:
      'Print vocabulary: papa, paté, tape, patate, patte, petite. Cursive vocabulary: papa, patate, tape, épi, patte, pipo.',
    proposedReviewAction:
      'Visually confirm the non-identical print/cursive lists and their ordering.',
  },
  'lesson-14-review-1': {
    currentStoredContent:
      'Stored sentence: “lulu à une patate.” Print vocabulary includes “lola”; the cursive vocabulary omits it.',
    proposedReviewAction:
      'Confirm the accented “à” and the print-only placement of “lola”.',
  },
  'lesson-21-review-1': {
    currentStoredContent: 'Stored sentence: “la gardien de la gare.”',
    proposedReviewAction:
      'Confirm that “la gardien” is the visible source wording; do not normalize grammar without explicit approval.',
  },
  'lesson-25-review-1': {
    currentStoredContent:
      'The print drill contains “sam”; the cursive drill omits it. The sequences are stored separately.',
    proposedReviewAction:
      'Confirm the print-only item and current representation split.',
  },
  'lesson-26-review-1': {
    currentStoredContent:
      'The passage stores “chaque famille retoune à la maison”. Print drill items “ron”, “von”, and “son” are absent from the cursive drill.',
    proposedReviewAction:
      'Confirm the visible spelling “retoune” and the print/cursive sequence difference.',
  },
  'lesson-29-review-1': {
    currentStoredContent:
      'The cursive sequence stores “je saute un chapeau” as one item because no separator is visible between “saute” and “un chapeau”.',
    proposedReviewAction:
      'Confirm whether the cursive source is one item or should be structurally separated without changing visible text.',
  },
  'lesson-31-review-1': {
    currentStoredContent:
      'Print drill contains “tein”; cursive contains “ein”. The passage stores “Sur la route Il achète…”.',
    proposedReviewAction:
      'Confirm both representation differences and the capital “Il” after “route” without a full stop.',
  },
  'lesson-32-review-1': {
    currentStoredContent:
      'Print adds “dou” and “lou” plus vocabulary involving “ouille”; the cursive source omits those items. Representations are stored separately.',
    proposedReviewAction:
      'Confirm the print-only items and current representation structure.',
  },
  'lesson-35-review-1': {
    currentStoredContent:
      'Stored passage: “Le soleil s’est levé Samira n’a plus sommeil…” with no punctuation between “levé” and “Samira”.',
    proposedReviewAction:
      'Confirm that the source visibly lacks punctuation; do not add punctuation without explicit approval.',
  },
  'lesson-40-review-1': {
    currentStoredContent:
      'The cursive list includes an isolated “un” and ends with “deux”; both are retained.',
    proposedReviewAction:
      'Confirm that both isolated items belong to the cursive list and are not layout artifacts.',
  },
  'lesson-46-review-1': {
    currentStoredContent:
      'The cursive source is stored as “une brique de quinze”, while print stores “une brique” and “quinze” separately.',
    proposedReviewAction:
      'Confirm whether the cursive source semantically joins the two items with “de”.',
  },
  'lesson-48-review-1': {
    currentStoredContent:
      'The print list contains “celui”; the cursive list omits it. Representations are stored separately.',
    proposedReviewAction:
      'Confirm the print-only item and current representation structure.',
  },
  'lesson-49-review-1': {
    currentStoredContent:
      'Lesson 49 provenance cites PDF pages 80 and 81, both showing printed page 79; semantic content is stored once.',
    proposedReviewAction:
      'Confirm that the two physical pages are duplicates and that one semantic representation is correct.',
  },
  'lesson-50-review-1': {
    currentStoredContent:
      'Stored passage begins “À kérou, …” with lowercase “k”.',
    proposedReviewAction:
      'Confirm the visible lowercase place-name spelling; do not normalize capitalization without explicit approval.',
  },
  'lesson-52-review-1': {
    currentStoredContent: 'Stored passage uses “charette”.',
    proposedReviewAction:
      'Confirm the visible spelling; do not silently normalize it.',
  },
  'lesson-53-review-1': {
    currentStoredContent:
      'Print contains “l’habitation”; cursive contains “l’action” and “une habitation”. Lists are stored separately.',
    proposedReviewAction:
      'Confirm the distinct print/cursive vocabulary and ordering.',
  },
  'lesson-55-review-1': {
    currentStoredContent:
      'The cursive list alone contains “une ardoise.” including the visible full stop.',
    proposedReviewAction: 'Confirm the cursive-only item and punctuation.',
  },
  'lesson-56-review-1': {
    currentStoredContent:
      'Provenance cites duplicate PDF pages 88 and 89 for printed page 86 and PDF page 90 for printed page 87; duplicate semantics are stored once.',
    proposedReviewAction:
      'Confirm the duplicate-page interpretation and single semantic representation.',
  },
  'back-cover-review-1': {
    currentStoredContent:
      'Stored quote includes “nous devons révéler le pourvoir des femmes”.',
    proposedReviewAction:
      'Confirm the visible back-cover wording; do not replace “pourvoir” without explicit approval.',
  },
};

function collectAssetReferences(value, result = new Set()) {
  if (Array.isArray(value)) {
    for (const item of value) collectAssetReferences(item, result);
  } else if (value && typeof value === 'object') {
    for (const [key, child] of Object.entries(value)) {
      if (key === 'assetId' && typeof child === 'string') result.add(child);
      else if (key === 'glyphAssetIds' && Array.isArray(child)) {
        for (const assetId of child) result.add(assetId);
      } else collectAssetReferences(child, result);
    }
  }
  return [...result];
}

function validProvenance(source) {
  const positiveUnique = (values) =>
    Array.isArray(values) &&
    values.every((value) => Number.isInteger(value) && value > 0) &&
    new Set(values).size === values.length;
  return (
    positiveUnique(source?.pdfPages) &&
    source.pdfPages.length > 0 &&
    positiveUnique(source?.printedPages)
  );
}

const auditItems = issues.map((issue) => {
  const affected = records.filter((record) =>
    record.data.review?.issueIds?.includes(issue.id),
  );
  const isAdjudicated = issue.status !== 'pending';
  const isHumanIssue = issue.type !== 'asset_uncertainty';
  const humanRequired = !isAdjudicated && isHumanIssue;
  const assetReferences = affected.flatMap((record) =>
    collectAssetReferences(record.data),
  );
  const detail = humanIssueDetails[issue.id];

  return {
    issueId: issue.id,
    issueType: issue.type,
    affectedContent: affected.map(({ kind, id, label }) => ({
      kind,
      id,
      label,
    })),
    pdfPages: issue.source.pdfPages,
    printedPages: issue.source.printedPages,
    currentStoredContent: isHumanIssue
      ? detail?.currentStoredContent
      : `Linked unresolved asset references: ${assetReferences.join(', ') || 'none found'}.`,
    observedSourceContent: issue.observedContent,
    existingNote: issue.note ?? null,
    currentStatus: issue.status,
    decisionNote: issue.decisionNote ?? null,
    humanAdjudicationRequired: humanRequired,
    classification: isAdjudicated
      ? 'ADJUDICATED'
      : humanRequired
        ? 'HUMAN_DECISION_REQUIRED'
        : 'EXTRACTION_BACKLOG_ONLY',
    proposedReviewAction: isAdjudicated
      ? 'No further action required unless a later source-fidelity defect is identified.'
      : humanRequired
        ? detail?.proposedReviewAction
        : 'Carry forward to Phase 3 extraction. Do not ask for content adjudication unless extraction reveals crop, identity, depiction, or association uncertainty.',
    provenanceValid: validProvenance(issue.source),
  };
});

const typeOrder = [
  'suspected_source_issue',
  'transcription_uncertainty',
  'layout_uncertainty',
  'asset_uncertainty',
];

const groups = Object.fromEntries(
  typeOrder.map((type) => [
    type,
    auditItems.filter((item) => item.issueType === type),
  ]),
);

const audit = {
  phase: '2D',
  schemaVersion: '1.0.2',
  productionContentModified: false,
  summary: {
    totalIssues: auditItems.length,
    countByType: Object.fromEntries(
      typeOrder.map((type) => [type, groups[type].length]),
    ),
    countByStatus: Object.fromEntries(
      [...new Set(issues.map((issue) => issue.status))]
        .sort()
        .map((status) => [
          status,
          issues.filter((issue) => issue.status === status).length,
        ]),
    ),
    humanIssuesTotal: auditItems.filter(
      (item) => item.issueType !== 'asset_uncertainty',
    ).length,
    humanIssuesAdjudicated: auditItems.filter(
      (item) =>
        item.issueType !== 'asset_uncertainty' &&
        item.classification === 'ADJUDICATED',
    ).length,
    humanDecisionRequired: auditItems.filter(
      (item) => item.classification === 'HUMAN_DECISION_REQUIRED',
    ).length,
    extractionBacklogOnly: auditItems.filter(
      (item) => item.classification === 'EXTRACTION_BACKLOG_ONLY',
    ).length,
    adjudicated: auditItems.filter(
      (item) => item.classification === 'ADJUDICATED',
    ).length,
    exactDuplicateIssueIds: [],
    patternedButDistinctIssues: [
      'The 24 asset_uncertainty records share one extraction-backlog pattern but remain distinct because each is linked to a different lesson and source location.',
    ],
    missingOrInvalidProvenance: auditItems
      .filter((item) => !item.provenanceValid)
      .map((item) => item.issueId),
    missingAffectedContentLinks: auditItems
      .filter((item) => item.affectedContent.length === 0)
      .map((item) => item.issueId),
  },
  groups,
};

const batchOneIds = [
  'lesson-08-review-1',
  'lesson-09-review-1',
  'lesson-14-review-1',
  'lesson-21-review-1',
  'lesson-26-review-1',
  'lesson-29-review-1',
  'lesson-31-review-1',
];

const batchTwoIds = [
  'lesson-25-review-1',
  'lesson-32-review-1',
  'lesson-35-review-1',
  'lesson-40-review-1',
  'lesson-46-review-1',
  'lesson-48-review-1',
  'lesson-50-review-1',
];

const batchThreeIds = [
  'lesson-49-review-1',
  'lesson-52-review-1',
  'lesson-53-review-1',
  'lesson-55-review-1',
  'lesson-56-review-1',
  'back-cover-review-1',
];

const batchQuestions = {
  'lesson-08-review-1':
    'Does the source show print “tite” and cursive “titi”, and should they remain separate representation-specific sequences?',
  'lesson-09-review-1':
    'Are both non-identical vocabulary lists transcribed and separated correctly?',
  'lesson-14-review-1':
    'Does the source visibly contain “lulu à une patate.” and print-only “lola” as currently stored?',
  'lesson-21-review-1':
    'Does the source visibly read “la gardien de la gare.” exactly as stored?',
  'lesson-26-review-1':
    'Does the source visibly use “retoune”, and are “ron”, “von”, and “son” print-only?',
  'lesson-29-review-1':
    'Should the unseparated cursive text remain one item, “je saute un chapeau”, or should its structure be adjusted?',
  'lesson-31-review-1':
    'Does the source show print “tein”, cursive “ein”, and “Sur la route Il” exactly as stored?',
  'lesson-25-review-1':
    'Does the source show “sam” in the print drill while omitting it from the cursive drill, as currently stored?',
  'lesson-32-review-1':
    'Does the source show print-only “dou”, “lou”, and vocabulary involving “ouille”, as currently stored?',
  'lesson-35-review-1':
    'Does the source visibly lack punctuation between “levé” and “Samira”, as currently stored?',
  'lesson-40-review-1':
    'Are the isolated “un” and terminal “deux” visible cursive-list items rather than layout artifacts?',
  'lesson-46-review-1':
    'Does the cursive source join the print items “une brique” and “quinze” as “une brique de quinze”?',
  'lesson-48-review-1':
    'Does “celui” appear only in the print list, as currently stored?',
  'lesson-50-review-1':
    'Does the source visibly begin “À kérou” with a lowercase “k”, as currently stored?',
  'lesson-49-review-1':
    'Are PDF pages 80 and 81 duplicate copies of printed page 79, making one semantic lesson representation correct?',
  'lesson-52-review-1':
    'Does the source visibly use the spelling “charette”, as currently stored?',
  'lesson-53-review-1':
    'Does print contain “l’habitation” while cursive contains “l’action” and “une habitation”, as currently stored?',
  'lesson-55-review-1':
    'Does “une ardoise.” appear only in the cursive list with its visible full stop, as currently stored?',
  'lesson-56-review-1':
    'Are PDF pages 88 and 89 duplicate copies of printed page 86, with PDF page 90 containing the distinct printed page 87?',
  'back-cover-review-1':
    'Does the back cover visibly read “nous devons révéler le pourvoir des femmes”, as currently stored?',
};

const cropFiles = {
  'lesson-08-review-1': ['crops/issue-01-lesson-08.png'],
  'lesson-09-review-1': ['crops/issue-02-lesson-09.png'],
  'lesson-14-review-1': ['crops/issue-03-lesson-14.png'],
  'lesson-21-review-1': ['crops/issue-04-lesson-21.png'],
  'lesson-26-review-1': [
    'crops/issue-05a-lesson-26-drill.png',
    'crops/issue-05b-lesson-26-passage.png',
  ],
  'lesson-29-review-1': ['crops/issue-06-lesson-29.png'],
  'lesson-31-review-1': [
    'crops/issue-07a-lesson-31-drill.png',
    'crops/issue-07b-lesson-31-passage.png',
  ],
  'lesson-25-review-1': ['crops/issue-08-lesson-25.png'],
  'lesson-32-review-1': ['crops/issue-09-lesson-32.png'],
  'lesson-35-review-1': ['crops/issue-10-lesson-35.png'],
  'lesson-40-review-1': ['crops/issue-11-lesson-40.png'],
  'lesson-46-review-1': ['crops/issue-12-lesson-46.png'],
  'lesson-48-review-1': ['crops/issue-13-lesson-48.png'],
  'lesson-50-review-1': ['crops/issue-14-lesson-50.png'],
  'lesson-49-review-1': [
    'crops/issue-15a-lesson-49-pdf-80.png',
    'crops/issue-15b-lesson-49-pdf-81.png',
  ],
  'lesson-52-review-1': ['crops/issue-16-lesson-52.png'],
  'lesson-53-review-1': ['crops/issue-17-lesson-53.png'],
  'lesson-55-review-1': ['crops/issue-18-lesson-55.png'],
  'lesson-56-review-1': [
    'crops/issue-19a-lesson-56-pdf-88.png',
    'crops/issue-19b-lesson-56-pdf-89.png',
    'crops/issue-19c-lesson-56-pdf-90.png',
  ],
  'back-cover-review-1': ['crops/issue-20-back-cover.png'],
};

function buildBatch(issueIds, startingNumber) {
  return issueIds.map((issueId, index) => {
    const item = auditItems.find((candidate) => candidate.issueId === issueId);
    return {
      number: startingNumber + index,
      ...item,
      questionForHumanReviewer: batchQuestions[issueId],
      sourceCrops: cropFiles[issueId],
      options: {
        A: 'Confirm source as currently digitised; change status to confirmed_source without changing content.',
        B: 'Approve a correction only by supplying the exact replacement text.',
        C: 'Keep visible text but describe the required representation, ordering, or structural adjustment.',
        D: 'Keep pending.',
      },
    };
  });
}

const batchOne = buildBatch(batchOneIds, 1);
const batchTwo = buildBatch(batchTwoIds, 8);
const batchThree = buildBatch(batchThreeIds, 15);

fs.writeFileSync(
  path.join(reviewRoot, 'audit.json'),
  `${JSON.stringify(audit, null, 2)}\n`,
);
fs.writeFileSync(
  path.join(reviewRoot, 'batch-01/manifest.json'),
  `${JSON.stringify(
    {
      batch: 1,
      decisionsApplied: batchOne.every(
        (issue) => issue.currentStatus !== 'pending',
      ),
      issues: batchOne,
    },
    null,
    2,
  )}\n`,
);
fs.mkdirSync(path.join(reviewRoot, 'batch-02'), { recursive: true });
fs.writeFileSync(
  path.join(reviewRoot, 'batch-02/manifest.json'),
  `${JSON.stringify(
    {
      batch: 2,
      decisionsApplied: batchTwo.every(
        (issue) => issue.currentStatus !== 'pending',
      ),
      issues: batchTwo,
    },
    null,
    2,
  )}\n`,
);
fs.mkdirSync(path.join(reviewRoot, 'batch-03'), { recursive: true });
fs.writeFileSync(
  path.join(reviewRoot, 'batch-03/manifest.json'),
  `${JSON.stringify(
    {
      batch: 3,
      decisionsApplied: batchThree.every(
        (issue) => issue.currentStatus !== 'pending',
      ),
      issues: batchThree,
    },
    null,
    2,
  )}\n`,
);
