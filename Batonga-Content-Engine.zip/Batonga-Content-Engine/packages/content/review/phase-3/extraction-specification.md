# Phase 3 Asset Extraction Specification

## Source and provenance

- The original Batonga PDF is the sole visual authority and remains read-only.
- Render directly from the original PDF at 600 DPI for production extraction. Review screenshots and Phase 2D crops are not production masters.
- Record the PDF page, printed page, render DPI, pixel crop box, semantic owner, operations, dimensions, format, and QA outcome for every produced asset.
- Keep source-review crops separate from production assets.

## Textbook illustrations

- Preserve the original illustration, composition, proportions, orientation, and all visible marks belonging to it.
- Crop surrounding page content. Remove a uniform page-white background only where the boundary can be recovered without damaging the line art.
- Preserve anti-aliased edges during white-background removal. Do not redraw, trace, recreate, replace, or add information.
- Use transparent PNG for the current blue line-art illustrations. Keep raster source artwork raster.

## Handwriting and cursive forms

- Extract the actual visible source form. Do not use system, web, approximate cursive, or generated fonts.
- Preserve stroke shape, weight variation, accents, proportions, color, and spacing between disconnected components such as dots and accents.
- Use cleaned transparent PNG unless faithful vector geometry is already present and can be recovered without interpretive tracing. Do not create fake SVG wrappers or automatic traces.

## Logos, photographs, and decorative artwork

- None are registered in the current 68-asset contract. If later registered, retain photographic pixels and brand/decorative composition without generative cleanup or stylistic changes.
- Prefer lossless PNG for transparency or line art. Consider WebP only for photographic material after a source-fidelity comparison.

## Format and output policy

- Permitted production formats: `.png`, `.webp`, and `.svg`.
- Phase 3A uses transparent PNG for all six pilot assets because the selected source material is rasterized line/glyph artwork on a white page.
- Production paths are package-relative under `assets/illustrations/` or `assets/glyphs/`.
- Do not add a new runtime image dependency. The extraction script uses the bundled Pillow runtime; application validation uses Node built-ins.

## Processing operations

Allowed operations are limited to crop, technically reliable white-background cleanup, non-destructive contrast preservation, and format conversion. Every operation must be recorded in the registry and pilot manifest.

The Phase 3A background cleanup converts only page-white and near-white matte pixels to transparency, preserving colored edge pixels with white-matte recovery. It does not reshape strokes or illustration contours.

## Visual QA gate

An asset may become `available` only when direct source comparison confirms:

- correct source and semantic association;
- correct crop and orientation;
- no clipping, neighbouring text, or unrelated marks;
- no lost or invented visual content;
- faithful proportions and stroke shapes;
- intact accents and disconnected glyph components;
- clean transparency without edge damage;
- an existing, non-empty production file at the registered path.

If cleanup threatens fidelity, retain a white-background raster candidate and keep the asset unresolved for further review.
