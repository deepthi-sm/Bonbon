/* eslint-disable @typescript-eslint/no-require-imports */

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const reviewRoot = __dirname;
const packageRoot = path.resolve(reviewRoot, '../..');

function readJson(relativePath) {
  return JSON.parse(
    fs.readFileSync(path.join(packageRoot, relativePath), 'utf8'),
  );
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function sha256(filePath) {
  return crypto
    .createHash('sha256')
    .update(fs.readFileSync(filePath))
    .digest('hex');
}

const assets = readJson('content/assets.json');
const issues = readJson('review/issues.json');
const qaManifest = readJson('review/phase-3/qa-manifest.json');
const pilotManifest = readJson('review/phase-3/pilot/pilot-manifest.json');
const phase2dAudit = readJson('review/phase-2d/audit.json');
const frontMatter = readJson('content/front-matter/front-matter.json');
const numeracy = readJson('content/numeracy/units.json');
const referenceMaterials = readJson(
  'content/literacy/reference-materials.json',
);
const lessonFiles = fs
  .readdirSync(path.join(packageRoot, 'content/literacy'))
  .filter((filename) => /^lesson-\d+\.json$/.test(filename));

assert(lessonFiles.length === 56, 'Expected 56 literacy lessons');
assert(numeracy.units.length === 10, 'Expected 10 numeracy units');
assert(frontMatter.items.length === 8, 'Expected 8 front-matter items');
assert(referenceMaterials.length === 1, 'Expected 1 reference material');
assert(qaManifest.schemaVersion === '1.0.2', 'Schema version changed');
assert(assets.length === 68, 'Expected 68 assets');
assert(
  assets.every((asset) => asset.status === 'available'),
  'Every asset must be available',
);
assert(qaManifest.assets.length === 68, 'QA manifest must cover every asset');
assert(
  qaManifest.assets.every((asset) => asset.visualQaStatus === 'passed'),
  'Every QA record must pass visual QA',
);

const qaById = new Map(
  qaManifest.assets.map((asset) => [asset.assetId, asset]),
);
for (const asset of assets) {
  const qa = qaById.get(asset.id);
  assert(qa, `Missing QA record for ${asset.id}`);
  const resolved = path.resolve(packageRoot, asset.path);
  const boundary = `${path.resolve(packageRoot, 'assets')}${path.sep}`;
  assert(resolved.startsWith(boundary), `${asset.id} escapes asset tree`);
  assert(fs.statSync(resolved).size > 0, `${asset.id} is empty`);
  assert(
    ['.png', '.webp', '.svg'].includes(path.extname(resolved)),
    `${asset.id} has invalid format`,
  );
  assert(
    sha256(resolved) === qa.sha256,
    `${asset.id} hash differs from QA manifest`,
  );
}

assert(issues.length === 44, 'Expected 44 ReviewIssues');
assert(
  issues.every((issue) => issue.status === 'confirmed_source'),
  'Every ReviewIssue must be confirmed_source',
);
assert(
  issues.filter((issue) => issue.type === 'asset_uncertainty').length === 24,
  'Expected 24 asset issues',
);

const phase2dHumanIssues = Object.values(phase2dAudit.groups)
  .flat()
  .filter((issue) => issue.issueType !== 'asset_uncertainty');
assert(phase2dHumanIssues.length === 20, 'Expected 20 Phase 2D decisions');
for (const audited of phase2dHumanIssues) {
  const current = issues.find((issue) => issue.id === audited.issueId);
  assert(current, `Missing Phase 2D issue ${audited.issueId}`);
  assert(
    current.status === audited.currentStatus,
    `Status changed for ${audited.issueId}`,
  );
  assert(
    current.decisionNote === audited.decisionNote,
    `Decision changed for ${audited.issueId}`,
  );
}

for (const pilot of pilotManifest.assets) {
  const resolved = path.resolve(packageRoot, pilot.productionPath);
  assert(
    sha256(resolved) === pilot.output.sha256,
    `Phase 3A pilot changed: ${pilot.assetId}`,
  );
}

const result = {
  schemaVersion: qaManifest.schemaVersion,
  corpus: {
    literacyLessons: lessonFiles.length,
    numeracyUnits: numeracy.units.length,
    frontMatterItems: frontMatter.items.length,
    literacyReferenceMaterials: referenceMaterials.length,
  },
  assets: {
    total: assets.length,
    attempted: qaManifest.summary.attempted,
    available: qaManifest.summary.available,
    unresolved: qaManifest.summary.unresolved,
    visualQaPassed: qaManifest.summary.visualQaPassed,
  },
  reviewIssues: {
    total: issues.length,
    confirmedSource: issues.filter(
      (issue) => issue.status === 'confirmed_source',
    ).length,
    pending: issues.filter((issue) => issue.status === 'pending').length,
    phase2dHumanDecisionsUnchanged: phase2dHumanIssues.length,
  },
  phase3aPilotAssetsUnchanged: pilotManifest.assets.length,
};

console.log(JSON.stringify(result, null, 2));
