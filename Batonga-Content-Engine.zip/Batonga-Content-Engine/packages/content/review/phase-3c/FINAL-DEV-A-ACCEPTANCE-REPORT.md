# Final Dev A Acceptance Report

## 1. Repository/root

- Verified root: `/Users/shy/Documents/Codex/2026-09-17/wo`
- Branch: `main`
- The working tree remains intentionally uncommitted. Phase 3C did not run `git add`, commit, push, reset, clean, or delete source/QA files.

## 2. Schema version

Batonga Content Schema **v1.0.2** is still the active schema. Phase 3C made no schema change.

## 3. Semantic corpus counts

- Literacy lessons: **56/56**
- Numeracy units: **10/10** (0–9)
- Front-matter items: **8/8**
- Literacy reference materials: **1/1**

## 4. Asset counts

- Registered: **68**
- Available: **68**
- Unresolved: **0**
- Illustrations: **24**
- Cursive glyphs: **44**
- Visual-QA pass: **68/68**

## 5. ReviewIssue counts

- Total: **44**
- `confirmed_source`: **44**
- Pending: **0**
- By type: 24 `asset_uncertainty`, 18 `suspected_source_issue`, and 2 `layout_uncertainty`
- Phase 2D human adjudications: **20/20 unchanged**

## 6. Portability audit

Production content, repository/player code, schemas, registry, and validation configuration contain no local absolute path, `file://` URL, `tmp/pdfs/` dependency, or Phase 2D/3 artifact dependency. All production asset paths are package-relative and contained under `packages/content/assets`.

## 7. Machine-specific path findings

The production scan found **0 machine-specific path dependencies**.

The source-document basename `SYLLABAIRE BATONGA PDF (1).pdf` appears in exactly three production/validation records:

- `packages/content/src/content-data.ts`
- `packages/content/scripts/validate-content.ts`
- `packages/content/inventory/literacy-source-map.json`

These are portable provenance strings, not paths or runtime file reads.

Historical Phase 3 evidence retains absolute source/workspace paths in seven QA-only files: the Phase 3A and 3B reports, Phase 3 README, the Phase 3A pilot manifest, both Phase 3B bulk manifests, and the complete QA manifest. Phase 3C's generated portability JSON also records the audited repository root. These findings are intentionally preserved as audit provenance and are not runtime dependencies.

## 8. Asset-reference closure

The complete chain was proven:

```text
68 semantic references
→ 68 unique asset IDs
→ 68 registry records
→ 68 portable package-relative paths
→ 68 existing non-zero production files
```

Result: **68 referenced / 68 resolved / 0 dangling / 0 missing / 0 invalid paths / 0 unreferenced registry entries**.

## 9. Orphan asset result

The two production directories contain exactly 68 image files. Every file is registered and semantically referenced. Production orphan count: **0**. QA previews, contact sheets, source crops, and pilot evidence are outside production asset directories and are not production orphans.

## 10. Untracked-file classification

The exact pre-audit baseline contained **372 untracked files**. `untracked-file-audit.json` lists every path.

| Category                             | Count | Representative paths                                                                  |
| ------------------------------------ | ----: | ------------------------------------------------------------------------------------- |
| A. Required for production           |    68 | `assets/illustrations/*.png`, `assets/glyphs/*.png`                                   |
| B. Required source content           |    55 | Lessons 02–41 and 43–56, `reference-materials.json`                                   |
| C. Required test or validation       |     6 | 2 test files and 4 Phase 3 verifier/build scripts                                     |
| D. Required documentation or handoff |     7 | `SCHEMA_GAPS.md`, Phase 2D/3 reports and specifications                               |
| E. QA evidence worth keeping         |   180 | adjudication/source crops, QA previews, manifests, contact sheets, extraction scripts |
| F. Regenerable intermediate          |    55 | `tmp/pdfs/**` renders and inspection images                                           |
| G. Temporary / should not commit     |     1 | Phase 3 Python bytecode cache                                                         |
| H. Unknown requiring review          |     0 | none                                                                                  |

Phase 3C added seven audit/integration files before this report: six under `review/phase-3c` and `src/review-data.ts`. They are part of the intended commit rather than the 372-file baseline.

## 11. `.gitignore` assessment

Production illustration and glyph files are not ignored. The only additions are safe local scratch rules:

```gitignore
tmp/
__pycache__/
*.py[cod]
```

They hide the 55 regenerable renders and one Python bytecode cache from normal Git status. No required content, production asset, test, documentation, or durable QA artifact is excluded.

## 12. Fresh-checkout/self-contained assessment

A controlled copy was created at `/tmp/batonga-phase3c-sim` from the intended file set, excluding `.git`, `node_modules`, build output, environment overrides, `tmp`, and Python caches. Dependencies were supplied through the existing installation to avoid a network reinstall.

Without the original PDF or any local absolute path, the copy passed:

- default content validation;
- full-corpus validation;
- Phase 3B asset-integrity verification;
- Phase 3C portability/closure audit;
- all 281 tests.

The first whole-application build correctly rejected absent host application environment variables. After copying the committed `.env.example` to `.env`, as required by the root README, the production build passed. This requirement belongs to the existing authentication/database host application and is unrelated to the Batonga content package.

## 13. Public API assessment

`@core/content` exposes:

- `contentRepository`
- `createContentRepository`
- `LessonPlayer`
- `BlockRenderer`
- `contentAssets`
- `Lesson`
- `NumeracyUnit`
- `AudioRef`
- `ContentAsset`
- `ReviewIssue`

Consumers can retrieve lessons, numeracy, front matter, and literacy reference materials through repository methods. They do not need raw JSON, internal source paths, ReviewIssue data, or physical PDF layout.

Asset IDs are resolved by the renderers against an injectable `ContentAsset[]`. Registry paths remain package-relative filesystem paths; the application must publish/import them and inject deployable URLs. This is sufficient for integration and is documented as a downstream adapter responsibility.

## 14. Dev-route assessment

`/dev/content` remains development-only and calls `notFound()` when `NODE_ENV=production`. It exposes representative repository content without source crops, manifests, contact sheets, or the original PDF. Phase 3C fixed the Lesson 42 and 56 preview calls to use the same data-URL asset adapter as the other samples, so all examples resolve package assets consistently.

## 15. Production-vs-QA separation

Production loading includes structured content, production assets, schemas/types, repository, and player/renderers. Phase 3C moved ReviewIssue value loading to `src/review-data.ts`, used only by internal validation/tests. The production `content-data.ts` no longer imports `review/issues.json` or any Phase review artifact.

ReviewIssues, source crops, QA previews, contact sheets, manifests, reports, extraction scripts, and the original PDF remain authoring/audit material. The application runtime does not require them.

## 16. Documentation status

`packages/content/README.md`, `HANDOFF.md`, and `DELIVERY_REPORT.md` now describe the completed Phase 3 corpus, Dev A ownership, repository retrieval, player use, production asset URL mapping, audio ownership, scope limits, source fidelity, and the no-silent-correction policy. Phase 3C also provides an exact untracked-file inventory and intended commit manifest.

## 17. Semantic immutability confirmation

A SHA-256 baseline covered **130 files**: all literacy/numeracy/front-matter/reference JSON, asset registry, ReviewIssues, and 68 production images. The final comparison found **0 changed files**.

Phase 3C changed no instructional text, targets/order, front-matter text, alphabet content, Phase 2D decision, registry semantic record, or production asset byte. Its code changes are limited to review-data isolation and consistent development-preview asset mapping.

## 18. Validation

- `npm run validate-content`: **PASS** — 56 lessons, 10 units, 8 front-matter items, 1 reference material, 68 asset references, 44 ReviewIssues.
- `CONTENT_VALIDATION_MODE=full npm run validate-content`: **PASS** with the same complete counts.
- `node packages/content/review/phase-3/verify-phase-3b.cjs`: **PASS** — 68/68 available and QA-approved, 44/44 confirmed, 20 Phase 2D decisions unchanged, 6 Phase 3A pilot assets unchanged.
- `node packages/content/review/phase-3c/audit-portability.cjs`: **PASS** — closure, portability, public API, QA separation, and production-route guard.

## 19. Tests

`npm test`: **PASS — 44 files, 281 tests**.

## 20. Typecheck/lint/format/build

- `npm run typecheck`: **PASS**
- `npm run lint`: **PASS**
- `npm run format:check`: **PASS**
- `npm run build`: **PASS**
- Controlled-copy build using the committed environment template: **PASS**

## 21. `git diff --check`

`git diff --check`: **PASS**.

## 22. Intended commit manifest

Commit the production content/assets, source/schema/player/repository changes, tests/validators, updated handoff documentation, ReviewIssue records, and durable Phase 2D/3/3C evidence. Do not commit `tmp/`, Python cache/bytecode, build output, dependency directories, logs, databases, or environment overrides.

The exact proposed boundary is in `INTENDED-COMMIT-MANIFEST.md`. Nothing was staged, committed, or pushed.

## 23. Remaining blockers

There are **no semantic, schema, provenance, asset, review, portability, validation, test, or build blockers** for Dev A handoff.

## 24. Remaining non-blocking work

- The application must map the package-relative production files to deployable browser URLs and pass the mapped asset collection to the player/renderers.
- The audio subsystem must implement recordings/TTS, delivery, caching, and playback for existing `AudioRef` keys.
- Product teams still own learner UI/state, authentication, authorization, submissions, analytics, and other application behavior.
- Before a future commit, follow the proposed manifest and leave the 56 ignored scratch/cache files uncommitted.

## 25. Downstream integration readiness

The repository is self-contained for content validation, repository loading, renderer use, asset-file resolution, tests, and production build with the host application's documented environment setup. Downstream integration can begin without the original PDF and without importing QA artifacts or raw content JSON.

The package passes Dev A acceptance. The browser asset URL adapter and audio implementation are explicit downstream responsibilities, so they remain non-blocking follow-up work rather than Dev A defects.

DEV A ACCEPTANCE: PASS WITH NON-BLOCKING FOLLOW-UP
