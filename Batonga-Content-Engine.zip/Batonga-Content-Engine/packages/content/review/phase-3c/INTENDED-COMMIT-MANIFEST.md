# Phase 3C Intended Commit Manifest

This is a proposal only. Phase 3C does not run `git add`, commit, or push.

## COMMIT

### Production content

- `packages/content/content/`
- `packages/content/inventory/literacy-source-map.json`

### Production assets

- `packages/content/assets/illustrations/`
- `packages/content/assets/glyphs/`
- `packages/content/assets/README.md`

### Source code, schemas, types, and integration route

- `packages/content/src/`
- `components/dev/content-demo.tsx`
- `app/dev/content/page.tsx` when not already committed
- `packages/content/scripts/validate-content.ts`

### Tests and validation

- `packages/content/tests/`
- `packages/content/review/phase-3/*.cjs`
- `packages/content/review/phase-2d/build-audit.cjs`
- `packages/content/review/phase-3c/`

### Required documentation and durable QA evidence

- `packages/content/README.md`
- `packages/content/HANDOFF.md`
- `packages/content/DELIVERY_REPORT.md`
- `packages/content/SCHEMA_GAPS.md`
- `packages/content/review/issues.json`
- `packages/content/review/phase-2d/`
- `packages/content/review/phase-3/`, excluding Python bytecode/cache files
- `.gitignore`

The retained QA evidence includes adjudication crops, source crops, processed previews, manifests, checkpoints, contact sheets, extraction scripts/specification, and delivery reports. These files are not runtime dependencies, but they make source fidelity and visual approval reproducible and reviewable.

## DO NOT COMMIT

- `tmp/` and its rendered PDF/layout/inspection images;
- any `__pycache__/` directory;
- `*.pyc`, `*.pyo`, or `*.pyd` files;
- `.next/`, `node_modules/`, coverage, logs, local databases, or environment overrides.

## REVIEW BEFORE COMMIT

None from the 372-file pre-audit baseline. The audit classified 0 files as unknown. A maintainer may choose a narrower QA-retention policy, but must keep the final manifests, source/processed evidence, and reports needed to audit all 68 accepted assets.
