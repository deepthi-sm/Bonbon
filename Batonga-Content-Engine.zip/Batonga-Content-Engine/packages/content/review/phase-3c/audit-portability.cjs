/* eslint-disable @typescript-eslint/no-require-imports */

const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '../../../..');
const packageRoot = path.join(root, 'packages/content');
const readJson = (relativePath) =>
  JSON.parse(fs.readFileSync(path.join(packageRoot, relativePath), 'utf8'));
const walkFiles = (directory) =>
  fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const target = path.join(directory, entry.name);
    return entry.isDirectory() ? walkFiles(target) : [target];
  });

const lessonFiles = walkFiles(
  path.join(packageRoot, 'content/literacy'),
).filter((file) => /lesson-\d+\.json$/.test(file));
const lessons = lessonFiles.map((file) => JSON.parse(fs.readFileSync(file)));
const references = [];
const collectReferences = (value, owner) => {
  if (Array.isArray(value)) {
    for (const child of value) collectReferences(child, owner);
    return;
  }
  if (!value || typeof value !== 'object') return;
  for (const [key, child] of Object.entries(value)) {
    if (key === 'assetId' && typeof child === 'string') {
      references.push({ id: child, owner });
    } else if (
      key === 'glyphAssetIds' &&
      Array.isArray(child) &&
      child.every((item) => typeof item === 'string')
    ) {
      for (const id of child) references.push({ id, owner });
    } else {
      collectReferences(child, owner);
    }
  }
};
for (const lesson of lessons) collectReferences(lesson, lesson.id);

const assets = readJson('content/assets.json');
const registeredIds = new Set(assets.map((asset) => asset.id));
const referencedIds = new Set(references.map(({ id }) => id));
const assetRoot = path.join(packageRoot, 'assets');
const productionFiles = walkFiles(assetRoot)
  .filter((file) => /\.(png|jpe?g|svg|webp)$/i.test(file))
  .map((file) => path.relative(packageRoot, file).split(path.sep).join('/'));
const dangling = [...referencedIds].filter((id) => !registeredIds.has(id));
const missing = [];
const invalidPaths = [];
for (const asset of assets) {
  if (asset.status !== 'available' || !asset.path) {
    missing.push({ id: asset.id, reason: 'not available or pathless' });
    continue;
  }
  const normalized = path.posix.normalize(asset.path);
  const target = path.resolve(packageRoot, asset.path);
  if (
    path.isAbsolute(asset.path) ||
    normalized.startsWith('../') ||
    !normalized.startsWith('assets/') ||
    !target.startsWith(`${assetRoot}${path.sep}`)
  ) {
    invalidPaths.push({ id: asset.id, path: asset.path });
    continue;
  }
  if (!fs.existsSync(target) || fs.statSync(target).size === 0) {
    missing.push({ id: asset.id, path: asset.path });
  }
}
const orphans = productionFiles.filter(
  (file) => !assets.some((asset) => asset.path === file),
);
const unreferencedRegistry = assets
  .filter((asset) => !referencedIds.has(asset.id))
  .map((asset) => asset.id);

const productionTextFiles = [
  ...walkFiles(path.join(packageRoot, 'content')),
  ...walkFiles(path.join(packageRoot, 'src')),
  ...walkFiles(path.join(packageRoot, 'scripts')),
  path.join(packageRoot, 'inventory/literacy-source-map.json'),
].filter((file) => /\.(json|ts|tsx|js|cjs|mjs)$/.test(file));
const forbidden = [
  '/Users/shy/',
  '/Users/',
  'Desktop/',
  'Documents/Codex/',
  'file://',
  'tmp/pdfs/',
  'review/phase-2d/',
  'review/phase-3/',
];
const machineSpecificHits = [];
const sourceBasenameHits = [];
for (const file of productionTextFiles) {
  const text = fs.readFileSync(file, 'utf8');
  for (const token of forbidden) {
    if (text.includes(token)) {
      machineSpecificHits.push({
        file: path.relative(root, file),
        token,
      });
    }
  }
  if (text.includes('SYLLABAIRE BATONGA PDF (1).pdf')) {
    sourceBasenameHits.push(path.relative(root, file));
  }
}

const publicIndex = fs.readFileSync(
  path.join(packageRoot, 'src/index.ts'),
  'utf8',
);
const requiredApi = [
  'contentRepository',
  'createContentRepository',
  'LessonPlayer',
  'BlockRenderer',
  './schema/lesson',
  './schema/numeracy',
  './schema/audio',
  './schema/assets',
  './schema/review',
];
const missingApi = requiredApi.filter((name) => !publicIndex.includes(name));
const contentData = fs.readFileSync(
  path.join(packageRoot, 'src/content-data.ts'),
  'utf8',
);
const bookSchema = fs.readFileSync(
  path.join(packageRoot, 'src/schema/book.ts'),
  'utf8',
);
const devRoute = fs.readFileSync(
  path.join(root, 'app/dev/content/page.tsx'),
  'utf8',
);

const result = {
  repositoryRoot: root,
  schemaVersion: bookSchema.match(/CONTENT_SCHEMA_VERSION = '([^']+)'/)?.[1],
  corpus: {
    literacyLessons: lessons.length,
    numeracyUnits: readJson('content/numeracy/units.json').units.length,
    frontMatterItems: readJson('content/front-matter/front-matter.json').items
      .length,
    literacyReferenceMaterials: readJson(
      'content/literacy/reference-materials.json',
    ).length,
  },
  assets: {
    semanticReferences: references.length,
    uniqueSemanticReferences: referencedIds.size,
    registered: assets.length,
    available: assets.filter((asset) => asset.status === 'available').length,
    unresolved: assets.filter((asset) => asset.status === 'unresolved').length,
    resolved: assets.length - missing.length - invalidPaths.length,
    dangling,
    missing,
    invalidPaths,
    unreferencedRegistry,
    productionFiles: productionFiles.length,
    orphans,
  },
  portability: {
    machineSpecificProductionHits: machineSpecificHits,
    sourceDocumentBasenameHits: sourceBasenameHits,
  },
  publicApi: { missing: missingApi },
  separation: {
    productionContentImportsReviewIssues: contentData.includes(
      '../review/issues.json',
    ),
    productionContentImportsPhaseArtifacts: /review\/phase-[23]/.test(
      contentData,
    ),
  },
  devRoute: {
    productionNotFoundGuard:
      devRoute.includes("process.env.NODE_ENV === 'production'") &&
      devRoute.includes('notFound()'),
  },
};

const failures = [
  result.corpus.literacyLessons !== 56,
  result.corpus.numeracyUnits !== 10,
  result.corpus.frontMatterItems !== 8,
  result.corpus.literacyReferenceMaterials !== 1,
  references.length !== 68,
  referencedIds.size !== 68,
  assets.length !== 68,
  result.assets.available !== 68,
  result.assets.unresolved !== 0,
  dangling.length > 0,
  missing.length > 0,
  invalidPaths.length > 0,
  unreferencedRegistry.length > 0,
  orphans.length > 0,
  machineSpecificHits.length > 0,
  missingApi.length > 0,
  result.separation.productionContentImportsReviewIssues,
  result.separation.productionContentImportsPhaseArtifacts,
  !result.devRoute.productionNotFoundGuard,
].filter(Boolean);

fs.writeFileSync(
  path.join(__dirname, 'portability-audit.json'),
  `${JSON.stringify(result, null, 2)}\n`,
);
console.log(JSON.stringify(result, null, 2));
if (failures.length) process.exitCode = 1;
