import { readdir, readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

import { validateContentBundle } from '../src/validation/validate-content';

const packageRoot = fileURLToPath(new URL('..', import.meta.url));

async function readJson(relativePath: string): Promise<unknown> {
  const url = new URL(`../${relativePath}`, import.meta.url);
  return JSON.parse(await readFile(url, 'utf8')) as unknown;
}

async function readLiteracyLessons(): Promise<unknown[]> {
  const directory = new URL('../content/literacy/', import.meta.url);
  const filenames = (await readdir(directory))
    .filter((filename) => /^lesson-[a-z0-9-]+\.json$/.test(filename))
    .sort();
  return Promise.all(
    filenames.map((filename) => readJson(`content/literacy/${filename}`)),
  );
}

async function main(): Promise<void> {
  const [
    assets,
    frontMatter,
    lessons,
    referenceMaterials,
    sections,
    numeracy,
    reviewIssues,
  ] = await Promise.all([
    readJson('content/assets.json'),
    readJson('content/front-matter/front-matter.json'),
    readLiteracyLessons(),
    readJson('content/literacy/reference-materials.json'),
    readJson('content/literacy/sections.json'),
    readJson('content/numeracy/units.json'),
    readJson('review/issues.json'),
  ]);

  const result = validateContentBundle(
    {
      book: {
        id: 'batonga-syllabary',
        title: 'Syllabaire Batonga',
        language: 'français',
        sourceDocument: 'SYLLABAIRE BATONGA PDF (1).pdf',
        frontMatter,
        literacy: { sections, lessons, referenceMaterials },
        numeracy,
      },
      assets,
      reviewIssues,
    },
    {
      mode: process.env.CONTENT_VALIDATION_MODE === 'full' ? 'full' : 'fixture',
      packageRoot,
    },
  );

  process.stdout.write(
    `Content valid: ${result.book.literacy.lessons.length} literacy lessons, ` +
      `${result.book.numeracy.units.length} numeracy units, ` +
      `${result.book.frontMatter.items.length} front-matter items, ` +
      `${result.book.literacy.referenceMaterials.length} literacy reference material, ` +
      `${result.assets.length} asset references, ${result.reviewIssues.length} review issues.\n`,
  );
}

await main();
