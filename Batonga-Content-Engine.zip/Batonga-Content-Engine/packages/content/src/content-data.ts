import lesson01Json from '../content/literacy/lesson-01.json';
import lesson02Json from '../content/literacy/lesson-02.json';
import lesson03Json from '../content/literacy/lesson-03.json';
import lesson04Json from '../content/literacy/lesson-04.json';
import lesson05Json from '../content/literacy/lesson-05.json';
import lesson06Json from '../content/literacy/lesson-06.json';
import lesson07Json from '../content/literacy/lesson-07.json';
import lesson08Json from '../content/literacy/lesson-08.json';
import lesson09Json from '../content/literacy/lesson-09.json';
import lesson10Json from '../content/literacy/lesson-10.json';
import lesson11Json from '../content/literacy/lesson-11.json';
import lesson12Json from '../content/literacy/lesson-12.json';
import lesson13Json from '../content/literacy/lesson-13.json';
import lesson14Json from '../content/literacy/lesson-14.json';
import lesson15Json from '../content/literacy/lesson-15.json';
import lesson16Json from '../content/literacy/lesson-16.json';
import lesson17Json from '../content/literacy/lesson-17.json';
import lesson18Json from '../content/literacy/lesson-18.json';
import lesson19Json from '../content/literacy/lesson-19.json';
import lesson20Json from '../content/literacy/lesson-20.json';
import lesson21Json from '../content/literacy/lesson-21.json';
import lesson22Json from '../content/literacy/lesson-22.json';
import lesson23Json from '../content/literacy/lesson-23.json';
import lesson24Json from '../content/literacy/lesson-24.json';
import lesson25Json from '../content/literacy/lesson-25.json';
import lesson26Json from '../content/literacy/lesson-26.json';
import lesson27Json from '../content/literacy/lesson-27.json';
import lesson28Json from '../content/literacy/lesson-28.json';
import lesson29Json from '../content/literacy/lesson-29.json';
import lesson30Json from '../content/literacy/lesson-30.json';
import lesson31Json from '../content/literacy/lesson-31.json';
import lesson32Json from '../content/literacy/lesson-32.json';
import lesson33Json from '../content/literacy/lesson-33.json';
import lesson34Json from '../content/literacy/lesson-34.json';
import lesson35Json from '../content/literacy/lesson-35.json';
import lesson36Json from '../content/literacy/lesson-36.json';
import lesson37Json from '../content/literacy/lesson-37.json';
import lesson38Json from '../content/literacy/lesson-38.json';
import lesson39Json from '../content/literacy/lesson-39.json';
import lesson40Json from '../content/literacy/lesson-40.json';
import lesson41Json from '../content/literacy/lesson-41.json';
import lesson42Json from '../content/literacy/lesson-42.json';
import lesson43Json from '../content/literacy/lesson-43.json';
import lesson44Json from '../content/literacy/lesson-44.json';
import lesson45Json from '../content/literacy/lesson-45.json';
import lesson46Json from '../content/literacy/lesson-46.json';
import lesson47Json from '../content/literacy/lesson-47.json';
import lesson48Json from '../content/literacy/lesson-48.json';
import lesson49Json from '../content/literacy/lesson-49.json';
import lesson50Json from '../content/literacy/lesson-50.json';
import lesson51Json from '../content/literacy/lesson-51.json';
import lesson52Json from '../content/literacy/lesson-52.json';
import lesson53Json from '../content/literacy/lesson-53.json';
import lesson54Json from '../content/literacy/lesson-54.json';
import lesson55Json from '../content/literacy/lesson-55.json';
import lesson56Json from '../content/literacy/lesson-56.json';
import assetsJson from '../content/assets.json';
import frontMatterJson from '../content/front-matter/front-matter.json';
import referenceMaterialsJson from '../content/literacy/reference-materials.json';
import sectionsJson from '../content/literacy/sections.json';
import numeracyJson from '../content/numeracy/units.json';
import { ContentAssetSchema } from './schema/assets';
import { BatongaBookSchema } from './schema/book';

export const contentAssets = ContentAssetSchema.array().parse(assetsJson);

export const batongaBook = BatongaBookSchema.parse({
  id: 'batonga-syllabary',
  title: 'Syllabaire Batonga',
  language: 'français',
  sourceDocument: 'SYLLABAIRE BATONGA PDF (1).pdf',
  frontMatter: frontMatterJson,
  literacy: {
    sections: sectionsJson,
    referenceMaterials: referenceMaterialsJson,
    lessons: [
      lesson01Json,
      lesson02Json,
      lesson03Json,
      lesson04Json,
      lesson05Json,
      lesson06Json,
      lesson07Json,
      lesson08Json,
      lesson09Json,
      lesson10Json,
      lesson11Json,
      lesson12Json,
      lesson13Json,
      lesson14Json,
      lesson15Json,
      lesson16Json,
      lesson17Json,
      lesson18Json,
      lesson19Json,
      lesson20Json,
      lesson21Json,
      lesson22Json,
      lesson23Json,
      lesson24Json,
      lesson25Json,
      lesson26Json,
      lesson27Json,
      lesson28Json,
      lesson29Json,
      lesson30Json,
      lesson31Json,
      lesson32Json,
      lesson33Json,
      lesson34Json,
      lesson35Json,
      lesson36Json,
      lesson37Json,
      lesson38Json,
      lesson39Json,
      lesson40Json,
      lesson41Json,
      lesson42Json,
      lesson43Json,
      lesson44Json,
      lesson45Json,
      lesson46Json,
      lesson47Json,
      lesson48Json,
      lesson49Json,
      lesson50Json,
      lesson51Json,
      lesson52Json,
      lesson53Json,
      lesson54Json,
      lesson55Json,
      lesson56Json,
    ],
  },
  numeracy: numeracyJson,
});
