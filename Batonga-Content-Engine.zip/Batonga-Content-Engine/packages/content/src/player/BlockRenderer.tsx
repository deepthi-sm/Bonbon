import { contentAssets } from '../content-data';
import type { ContentAsset } from '../schema/assets';
import type { LessonBlock } from '../schema/blocks';
import {
  DialogueRenderer,
  GraphemeRenderer,
  HandwritingDemoRenderer,
  IllustrationRenderer,
  InstructionListRenderer,
  NumeralDisplayRenderer,
  ReadingPassageRenderer,
  SectionTextRenderer,
  SentenceListRenderer,
  SyllableDrillRenderer,
  WordListRenderer,
  WritingPracticeRenderer,
} from './blocks';

export interface BlockRendererProps {
  block: LessonBlock;
  assets?: readonly ContentAsset[];
}

export function BlockRenderer({
  block,
  assets = contentAssets,
}: BlockRendererProps) {
  switch (block.type) {
    case 'grapheme':
      return <GraphemeRenderer block={block} />;
    case 'syllable_drill':
      return <SyllableDrillRenderer block={block} />;
    case 'word_list':
      return <WordListRenderer block={block} />;
    case 'sentence_list':
      return <SentenceListRenderer block={block} />;
    case 'reading_passage':
      return <ReadingPassageRenderer block={block} />;
    case 'dialogue':
      return <DialogueRenderer block={block} />;
    case 'instruction_list':
      return <InstructionListRenderer block={block} />;
    case 'illustration':
      return (
        <IllustrationRenderer
          block={block}
          asset={assets.find((asset) => asset.id === block.assetId)}
        />
      );
    case 'handwriting_demo':
      return <HandwritingDemoRenderer block={block} assets={assets} />;
    case 'writing_practice':
      return <WritingPracticeRenderer block={block} />;
    case 'numeral_display':
      return <NumeralDisplayRenderer block={block} />;
    case 'section_text':
      return <SectionTextRenderer block={block} />;
    default: {
      const exhaustive: never = block;
      return exhaustive;
    }
  }
}
