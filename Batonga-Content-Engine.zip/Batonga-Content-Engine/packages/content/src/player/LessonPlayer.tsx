import type { ContentAsset } from '../schema/assets';
import type { Lesson } from '../schema/lesson';
import { BlockRenderer } from './BlockRenderer';

export interface LessonPlayerProps {
  lesson: Lesson;
  assets?: readonly ContentAsset[];
}

export function LessonPlayer({ lesson, assets }: LessonPlayerProps) {
  return (
    <article data-lesson-id={lesson.id}>
      <header>
        <p>Leçon {String(lesson.lessonNumber).padStart(2, '0')}</p>
        {lesson.title ? <h2>{lesson.title}</h2> : null}
      </header>
      <div>
        {lesson.blocks.map((block) => (
          <BlockRenderer key={block.id} block={block} assets={assets} />
        ))}
      </div>
    </article>
  );
}
