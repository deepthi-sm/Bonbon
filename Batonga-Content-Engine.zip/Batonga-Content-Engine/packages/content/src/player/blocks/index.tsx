import type { ReactNode } from 'react';

import type { ContentAsset } from '../../schema/assets';
import type {
  DialogueBlock,
  GraphemeBlock,
  HandwritingDemoBlock,
  IllustrationBlock,
  InstructionListBlock,
  NumeralDisplayBlock,
  ReadingPassageBlock,
  SectionTextBlock,
  SentenceListBlock,
  SyllableDrillBlock,
  TextItem,
  WordListBlock,
  WritingPracticeBlock,
} from '../../schema/blocks';

function TextWithAudio({ item }: { item: TextItem }) {
  return (
    <span
      data-audio-key={item.audio?.key}
      data-representations={item.representations?.join(',')}
    >
      {item.text}
    </span>
  );
}

function OrderedItems({ items }: { items: TextItem[] }) {
  return (
    <ol>
      {items.map((item) => (
        <li key={item.id}>
          <TextWithAudio item={item} />
        </li>
      ))}
    </ol>
  );
}

function BlockFrame({ type, children }: { type: string; children: ReactNode }) {
  return <section data-block-type={type}>{children}</section>;
}

function DialogueTurns({ turns }: { turns: DialogueBlock['turns'] }) {
  return (
    <div data-dialogue-turns>
      {turns.map((turn) => (
        <blockquote
          key={turn.id}
          data-dialogue-turn={turn.speaker ? 'labelled' : 'unlabelled'}
        >
          {turn.speaker ? (
            <p>
              <strong>{turn.speaker}</strong>
            </p>
          ) : null}
          <p data-audio-key={turn.audio?.key}>{turn.text}</p>
        </blockquote>
      ))}
    </div>
  );
}

export function GraphemeRenderer({ block }: { block: GraphemeBlock }) {
  return (
    <BlockFrame type={block.type}>
      <p
        data-audio-key={block.audio?.key}
        data-representations={block.representations.join(',')}
      >
        <span>{block.grapheme}</span>
        {block.uppercase ? <span> {block.uppercase}</span> : null}
      </p>
    </BlockFrame>
  );
}

export function SyllableDrillRenderer({
  block,
}: {
  block: SyllableDrillBlock;
}) {
  return (
    <BlockFrame type={block.type}>
      <OrderedItems items={block.items} />
    </BlockFrame>
  );
}

export function WordListRenderer({ block }: { block: WordListBlock }) {
  return (
    <BlockFrame type={block.type}>
      <OrderedItems items={block.items} />
    </BlockFrame>
  );
}

export function SentenceListRenderer({ block }: { block: SentenceListBlock }) {
  return (
    <BlockFrame type={block.type}>
      <OrderedItems items={block.items} />
    </BlockFrame>
  );
}

export function ReadingPassageRenderer({
  block,
}: {
  block: ReadingPassageBlock;
}) {
  return (
    <BlockFrame type={block.type}>
      {block.title ? <h3>{block.title}</h3> : null}
      {block.segments.map((segment) =>
        segment.type === 'narration' ? (
          <p key={segment.id} data-audio-key={segment.audio?.key}>
            {segment.text}
          </p>
        ) : (
          <div key={segment.id} data-passage-segment="dialogue">
            <DialogueTurns turns={segment.turns} />
          </div>
        ),
      )}
    </BlockFrame>
  );
}

export function DialogueRenderer({ block }: { block: DialogueBlock }) {
  return (
    <BlockFrame type={block.type}>
      <DialogueTurns turns={block.turns} />
    </BlockFrame>
  );
}

export function InstructionListRenderer({
  block,
}: {
  block: InstructionListBlock;
}) {
  return (
    <BlockFrame type={block.type}>
      <OrderedItems items={block.items} />
    </BlockFrame>
  );
}

export function IllustrationRenderer({
  block,
  asset,
}: {
  block: IllustrationBlock;
  asset?: ContentAsset;
}) {
  const image = asset?.kind === 'image' ? asset : undefined;
  return (
    <BlockFrame type={block.type}>
      <figure
        data-asset-id={block.assetId}
        data-asset-status={image?.status ?? 'missing'}
      >
        {image?.status === 'available' && image.path ? (
          // Content consumers may replace this minimal path handling with their asset pipeline.
          // eslint-disable-next-line @next/next/no-img-element
          <img
            className="max-h-80 w-auto max-w-full object-contain"
            src={image.path}
            alt={image.alt}
          />
        ) : (
          <div
            role="img"
            aria-label={image?.alt ?? 'Illustration non disponible'}
          />
        )}
        {block.caption ? (
          <figcaption>
            <TextWithAudio item={block.caption} />
          </figcaption>
        ) : null}
      </figure>
    </BlockFrame>
  );
}

export function HandwritingDemoRenderer({
  block,
  assets,
}: {
  block: HandwritingDemoBlock;
  assets: readonly ContentAsset[];
}) {
  const glyphs = (block.glyphAssetIds ?? []).map((assetId) => ({
    assetId,
    asset: assets.find(
      (candidate) => candidate.id === assetId && candidate.kind === 'glyph',
    ),
  }));

  return (
    <BlockFrame type={block.type}>
      <div
        aria-label="Démonstration d’écriture"
        data-glyph-assets={block.glyphAssetIds?.join(',')}
        data-representations={block.representations.join(',')}
      >
        {glyphs.length > 0 ? (
          <div data-handwriting-source-assets>
            {glyphs.map(({ assetId, asset }) => {
              const glyph = asset?.kind === 'glyph' ? asset : undefined;
              return (
                <figure
                  key={assetId}
                  data-asset-id={assetId}
                  data-asset-status={glyph?.status ?? 'missing'}
                >
                  {glyph?.status === 'available' && glyph.path ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      className="max-h-40 w-auto max-w-full object-contain"
                      src={glyph.path}
                      alt={`Forme cursive source : ${glyph.character}`}
                    />
                  ) : (
                    <div
                      role="img"
                      aria-label={`Forme cursive non disponible : ${glyph?.character ?? assetId}`}
                    />
                  )}
                </figure>
              );
            })}
          </div>
        ) : null}
        {block.examples.map((example) => (
          <span key={example.id}>
            <TextWithAudio item={example} />
          </span>
        ))}
      </div>
    </BlockFrame>
  );
}

export function WritingPracticeRenderer({
  block,
}: {
  block: WritingPracticeBlock;
}) {
  return (
    <BlockFrame type={block.type}>
      <div data-representations={block.representations.join(',')}>
        <OrderedItems items={block.items} />
      </div>
    </BlockFrame>
  );
}

export function NumeralDisplayRenderer({
  block,
}: {
  block: NumeralDisplayBlock;
}) {
  return (
    <BlockFrame type={block.type}>
      <p data-audio-key={block.audio?.key}>
        <data value={block.value}>{block.display}</data>
        {block.word ? (
          <>
            {' '}
            <TextWithAudio item={block.word} />
          </>
        ) : null}
      </p>
    </BlockFrame>
  );
}

export function SectionTextRenderer({ block }: { block: SectionTextBlock }) {
  return (
    <BlockFrame type={block.type}>
      {block.heading ? <h3>{block.heading}</h3> : null}
      {block.paragraphs.map((paragraph) => (
        <p key={paragraph.id}>
          <TextWithAudio item={paragraph} />
        </p>
      ))}
    </BlockFrame>
  );
}
