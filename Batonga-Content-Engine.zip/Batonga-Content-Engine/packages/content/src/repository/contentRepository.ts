import { batongaBook } from '../content-data';
import { BatongaBookSchema } from '../schema/book';
import type {
  BatongaBook,
  FrontMatter,
  LiteracyReferenceMaterial,
  LiteracySection,
} from '../schema/book';
import type { Lesson } from '../schema/lesson';
import type { NumeracyUnit } from '../schema/numeracy';

export interface ContentRepository {
  getBook(): Readonly<BatongaBook>;
  getLiteracySections(): readonly Readonly<LiteracySection>[];
  getLiteracyReferenceMaterials(): readonly Readonly<LiteracyReferenceMaterial>[];
  getLiteracyReferenceMaterial(
    id: string,
  ): Readonly<LiteracyReferenceMaterial> | undefined;
  getLessons(): readonly Readonly<Lesson>[];
  getLesson(id: string): Readonly<Lesson> | undefined;
  getLessonByNumber(number: number): Readonly<Lesson> | undefined;
  getNextLesson(id: string): Readonly<Lesson> | undefined;
  getPreviousLesson(id: string): Readonly<Lesson> | undefined;
  getNumeracyUnits(): readonly Readonly<NumeracyUnit>[];
  getNumeracyUnit(number: number): Readonly<NumeracyUnit> | undefined;
  getFrontMatter(): Readonly<FrontMatter>;
}

function deepFreeze<T>(value: T): Readonly<T> {
  if (value !== null && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) {
      deepFreeze(child);
    }
  }

  return value;
}

export function createContentRepository(
  input: unknown = batongaBook,
): ContentRepository {
  const book = deepFreeze(BatongaBookSchema.parse(input));
  const lessons = deepFreeze(
    [...book.literacy.lessons].sort(
      (left, right) => left.lessonNumber - right.lessonNumber,
    ),
  );
  const lessonIndex = new Map(
    lessons.map((lesson, index) => [lesson.id, index]),
  );
  const lessonsByNumber = new Map(
    lessons.map((lesson) => [lesson.lessonNumber, lesson]),
  );
  const referenceMaterials = book.literacy.referenceMaterials;
  const referenceMaterialsById = new Map(
    referenceMaterials.map((material) => [material.id, material]),
  );
  const numeracyUnits = deepFreeze(
    [...book.numeracy.units].sort((left, right) => left.number - right.number),
  );

  return {
    getBook: () => book,
    getLiteracySections: () => book.literacy.sections,
    getLiteracyReferenceMaterials: () => referenceMaterials,
    getLiteracyReferenceMaterial: (id) => referenceMaterialsById.get(id),
    getLessons: () => lessons,
    getLesson: (id) => {
      const index = lessonIndex.get(id);
      return index === undefined ? undefined : lessons[index];
    },
    getLessonByNumber: (number) => lessonsByNumber.get(number),
    getNextLesson: (id) => {
      const index = lessonIndex.get(id);
      return index === undefined ? undefined : lessons[index + 1];
    },
    getPreviousLesson: (id) => {
      const index = lessonIndex.get(id);
      return index === undefined ? undefined : lessons[index - 1];
    },
    getNumeracyUnits: () => numeracyUnits,
    getNumeracyUnit: (number) =>
      numeracyUnits.find((unit) => unit.number === number),
    getFrontMatter: () => book.frontMatter,
  };
}

export const contentRepository = createContentRepository();
