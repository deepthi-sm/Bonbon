import reviewIssuesJson from '../review/issues.json';
import { ReviewIssueSchema } from './schema/review';

/** Authoring and audit data. Production consumers do not need this module. */
export const reviewIssues = ReviewIssueSchema.array().parse(reviewIssuesJson);
