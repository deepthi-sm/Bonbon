import { z } from 'zod';

import { NonEmptyTextSchema, SourceRefSchema, StableIdSchema } from './common';

const AssetStatusSchema = z.enum(['available', 'unresolved']);
const AssetPathSchema = z
  .string()
  .regex(/^assets\//, 'Asset paths must remain package-relative');

const ProcessingMetadataSchema = z.strictObject({
  operations: z.array(
    z.enum([
      'crop',
      'background_cleanup',
      'contrast_adjustment',
      'format_conversion',
    ]),
  ),
  notes: NonEmptyTextSchema.optional(),
});

export const ImageAssetSchema = z
  .strictObject({
    id: StableIdSchema,
    kind: z.literal('image'),
    status: AssetStatusSchema,
    alt: NonEmptyTextSchema,
    source: SourceRefSchema,
    path: AssetPathSchema.optional(),
    processing: ProcessingMetadataSchema.optional(),
  })
  .superRefine((asset, context) => {
    if (asset.status === 'available' && !asset.path) {
      context.addIssue({
        code: 'custom',
        path: ['path'],
        message:
          'Available image assets require a committed package-relative path',
      });
    }
    if (asset.status === 'unresolved' && asset.path) {
      context.addIssue({
        code: 'custom',
        path: ['path'],
        message: 'Unresolved image assets must not declare a path',
      });
    }
  });

export const GlyphAssetSchema = z
  .strictObject({
    id: StableIdSchema,
    kind: z.literal('glyph'),
    status: AssetStatusSchema,
    character: NonEmptyTextSchema,
    representation: z.literal('cursive'),
    source: SourceRefSchema,
    path: AssetPathSchema.optional(),
    processing: ProcessingMetadataSchema.optional(),
  })
  .superRefine((asset, context) => {
    if (asset.status === 'available' && !asset.path) {
      context.addIssue({
        code: 'custom',
        path: ['path'],
        message:
          'Available glyph assets require a committed package-relative path',
      });
    }
    if (asset.status === 'unresolved' && asset.path) {
      context.addIssue({
        code: 'custom',
        path: ['path'],
        message: 'Unresolved glyph assets must not declare a path',
      });
    }
  });

export const ContentAssetSchema = z.discriminatedUnion('kind', [
  ImageAssetSchema,
  GlyphAssetSchema,
]);

export type ImageAsset = z.infer<typeof ImageAssetSchema>;
export type GlyphAsset = z.infer<typeof GlyphAssetSchema>;
export type ContentAsset = z.infer<typeof ContentAssetSchema>;
