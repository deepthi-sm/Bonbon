import { z } from 'zod';

import { NonEmptyTextSchema } from './common';

export const AudioKeySchema = z
  .string()
  .regex(
    /^[a-z][a-z0-9_-]*(?::[a-z0-9][a-z0-9_-]*){2,}$/,
    'Audio keys must contain at least three lowercase colon-delimited segments',
  );

export const AudioRefSchema = z.strictObject({
  key: AudioKeySchema,
  fallbackText: NonEmptyTextSchema,
});

export type AudioRef = z.infer<typeof AudioRefSchema>;
