import { z } from 'zod';

import { AudioRefSchema } from './audio';
import { NonEmptyTextSchema, SourceRefSchema, StableIdSchema } from './common';

export const RepresentationSchema = z.enum(['print', 'cursive']);
export const RepresentationsSchema = z
  .array(RepresentationSchema)
  .min(1)
  .refine(
    (values) => new Set(values).size === values.length,
    'Representations must be unique',
  );

export const TextItemSchema = z.strictObject({
  id: StableIdSchema,
  text: NonEmptyTextSchema,
  audio: AudioRefSchema.optional(),
  representations: RepresentationsSchema.optional(),
});

const BlockBaseShape = {
  id: StableIdSchema,
  source: SourceRefSchema.optional(),
};

export const GraphemeBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('grapheme'),
  grapheme: NonEmptyTextSchema,
  uppercase: NonEmptyTextSchema.optional(),
  representations: RepresentationsSchema,
  audio: AudioRefSchema.optional(),
});

export const SyllableDrillBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('syllable_drill'),
  preserveSourceOrder: z.literal(true),
  items: z.array(TextItemSchema).min(1),
});

export const WordListBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('word_list'),
  preserveSourceOrder: z.literal(true),
  items: z.array(TextItemSchema).min(1),
});

export const SentenceListBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('sentence_list'),
  preserveSourceOrder: z.literal(true),
  items: z.array(TextItemSchema).min(1),
});

export const NarrationSegmentSchema = z.strictObject({
  id: StableIdSchema,
  type: z.literal('narration'),
  text: NonEmptyTextSchema,
  audio: AudioRefSchema.optional(),
});

export const DialogueTurnSchema = z.strictObject({
  id: StableIdSchema,
  speaker: NonEmptyTextSchema.optional(),
  text: NonEmptyTextSchema,
  audio: AudioRefSchema.optional(),
});

export const DialogueSegmentSchema = z.strictObject({
  id: StableIdSchema,
  type: z.literal('dialogue'),
  turns: z.array(DialogueTurnSchema).min(1),
});

export const ReadingPassageBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('reading_passage'),
  title: NonEmptyTextSchema.optional(),
  preserveSourceOrder: z.literal(true),
  segments: z
    .array(
      z.discriminatedUnion('type', [
        NarrationSegmentSchema,
        DialogueSegmentSchema,
      ]),
    )
    .min(1),
});

export const DialogueBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('dialogue'),
  preserveSourceOrder: z.literal(true),
  turns: z.array(DialogueTurnSchema).min(1),
});

export const InstructionListBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('instruction_list'),
  preserveSourceOrder: z.literal(true),
  items: z.array(TextItemSchema).min(1),
});

export const IllustrationBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('illustration'),
  assetId: StableIdSchema,
  caption: TextItemSchema.optional(),
});

export const HandwritingDemoBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('handwriting_demo'),
  representations: RepresentationsSchema,
  examples: z.array(TextItemSchema).min(1),
  glyphAssetIds: z.array(StableIdSchema).optional(),
});

export const WritingPracticeBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('writing_practice'),
  preserveSourceOrder: z.literal(true),
  representations: RepresentationsSchema,
  items: z.array(TextItemSchema).min(1),
});

export const NumeralDisplayBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('numeral_display'),
  value: z.number().int().min(0).max(9),
  display: NonEmptyTextSchema,
  word: TextItemSchema.optional(),
  audio: AudioRefSchema.optional(),
});

export const SectionTextBlockSchema = z.strictObject({
  ...BlockBaseShape,
  type: z.literal('section_text'),
  heading: NonEmptyTextSchema.optional(),
  preserveSourceOrder: z.literal(true),
  paragraphs: z.array(TextItemSchema).min(1),
});

export const LessonBlockSchema = z.discriminatedUnion('type', [
  GraphemeBlockSchema,
  SyllableDrillBlockSchema,
  WordListBlockSchema,
  SentenceListBlockSchema,
  ReadingPassageBlockSchema,
  DialogueBlockSchema,
  InstructionListBlockSchema,
  IllustrationBlockSchema,
  HandwritingDemoBlockSchema,
  WritingPracticeBlockSchema,
  NumeralDisplayBlockSchema,
  SectionTextBlockSchema,
]);

export type TextItem = z.infer<typeof TextItemSchema>;
export type GraphemeBlock = z.infer<typeof GraphemeBlockSchema>;
export type SyllableDrillBlock = z.infer<typeof SyllableDrillBlockSchema>;
export type WordListBlock = z.infer<typeof WordListBlockSchema>;
export type SentenceListBlock = z.infer<typeof SentenceListBlockSchema>;
export type ReadingPassageBlock = z.infer<typeof ReadingPassageBlockSchema>;
export type DialogueBlock = z.infer<typeof DialogueBlockSchema>;
export type InstructionListBlock = z.infer<typeof InstructionListBlockSchema>;
export type IllustrationBlock = z.infer<typeof IllustrationBlockSchema>;
export type HandwritingDemoBlock = z.infer<typeof HandwritingDemoBlockSchema>;
export type WritingPracticeBlock = z.infer<typeof WritingPracticeBlockSchema>;
export type NumeralDisplayBlock = z.infer<typeof NumeralDisplayBlockSchema>;
export type SectionTextBlock = z.infer<typeof SectionTextBlockSchema>;
export type LessonBlock = z.infer<typeof LessonBlockSchema>;
