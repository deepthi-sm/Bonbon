import { z } from 'zod';

import { AudioRefSchema } from './audio';
import {
  IllustrationBlockSchema,
  RepresentationsSchema,
  SectionTextBlockSchema,
} from './blocks';
import { NonEmptyTextSchema, SourceRefSchema, StableIdSchema } from './common';
import { LessonSchema } from './lesson';
import { NumeracyCurriculumSchema } from './numeracy';
import { ReviewMetadataSchema } from './review';

export const CONTENT_SCHEMA_VERSION = '1.0.2' as const;

const FrontMatterBaseShape = {
  id: StableIdSchema,
  source: SourceRefSchema,
  review: ReviewMetadataSchema,
};

export const FrontMatterItemSchema = z.discriminatedUnion('type', [
  z.strictObject({
    ...FrontMatterBaseShape,
    type: z.literal('cover'),
    title: NonEmptyTextSchema.optional(),
    blocks: z.array(
      z.discriminatedUnion('type', [
        IllustrationBlockSchema,
        SectionTextBlockSchema,
      ]),
    ),
  }),
  z.strictObject({
    ...FrontMatterBaseShape,
    type: z.literal('preface'),
    title: NonEmptyTextSchema.optional(),
    blocks: z.array(SectionTextBlockSchema),
  }),
  z.strictObject({
    ...FrontMatterBaseShape,
    type: z.literal('testimonial'),
    attribution: NonEmptyTextSchema.optional(),
    blocks: z.array(SectionTextBlockSchema),
  }),
  z.strictObject({
    ...FrontMatterBaseShape,
    type: z.literal('credits'),
    title: NonEmptyTextSchema.optional(),
    blocks: z.array(SectionTextBlockSchema),
  }),
]);

export const FrontMatterSchema = z.strictObject({
  items: z.array(FrontMatterItemSchema),
});

export const LiteracySectionSchema = z.strictObject({
  id: StableIdSchema,
  title: NonEmptyTextSchema,
  lessonNumbers: z.array(z.number().int().min(1).max(56)).min(1),
  source: SourceRefSchema,
});

export const AlphabetChartEntrySchema = z.strictObject({
  id: StableIdSchema,
  grapheme: NonEmptyTextSchema,
  uppercase: NonEmptyTextSchema,
  category: z.enum(['vowel', 'consonant']),
  representations: RepresentationsSchema,
  audio: AudioRefSchema.optional(),
});

export const AlphabetChartSchema = z.strictObject({
  id: StableIdSchema,
  type: z.literal('alphabet_chart'),
  title: NonEmptyTextSchema,
  preserveSourceOrder: z.literal(true),
  source: SourceRefSchema,
  entries: z.array(AlphabetChartEntrySchema).min(1),
  review: ReviewMetadataSchema,
});

export const LiteracyReferenceMaterialSchema = AlphabetChartSchema;

export const LiteracyCurriculumSchema = z.strictObject({
  sections: z.array(LiteracySectionSchema).min(1),
  lessons: z.array(LessonSchema).min(1),
  referenceMaterials: z.array(LiteracyReferenceMaterialSchema),
});

export const BatongaBookSchema = z.strictObject({
  id: StableIdSchema,
  title: NonEmptyTextSchema,
  language: NonEmptyTextSchema,
  sourceDocument: NonEmptyTextSchema,
  frontMatter: FrontMatterSchema,
  literacy: LiteracyCurriculumSchema,
  numeracy: NumeracyCurriculumSchema,
});

export type FrontMatterItem = z.infer<typeof FrontMatterItemSchema>;
export type FrontMatter = z.infer<typeof FrontMatterSchema>;
export type LiteracySection = z.infer<typeof LiteracySectionSchema>;
export type AlphabetChartEntry = z.infer<typeof AlphabetChartEntrySchema>;
export type AlphabetChart = z.infer<typeof AlphabetChartSchema>;
export type LiteracyReferenceMaterial = z.infer<
  typeof LiteracyReferenceMaterialSchema
>;
export type LiteracyCurriculum = z.infer<typeof LiteracyCurriculumSchema>;
export type BatongaBook = z.infer<typeof BatongaBookSchema>;
