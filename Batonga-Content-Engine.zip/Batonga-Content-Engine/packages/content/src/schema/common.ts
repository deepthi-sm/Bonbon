import { z } from 'zod';

export const StableIdSchema = z
  .string()
  .regex(
    /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/,
    'Use a stable lowercase kebab-case id',
  );

export const NonEmptyTextSchema = z
  .string()
  .refine((value) => value.trim().length > 0, 'Text cannot be blank');

const PositivePageSchema = z.number().int().positive();

export const BoundingBoxSchema = z
  .strictObject({
    x: z.number().finite().nonnegative(),
    y: z.number().finite().nonnegative(),
    width: z.number().finite().positive(),
    height: z.number().finite().positive(),
  })
  .describe('Source-page coordinates used only for extraction or review');

export const SourceRegionSchema = z.strictObject({
  pdfPage: PositivePageSchema,
  printedPage: PositivePageSchema.optional(),
  side: z.enum(['left', 'right']).optional(),
  bbox: BoundingBoxSchema.optional(),
});

export const SourceRefSchema = z
  .strictObject({
    pdfPages: z.array(PositivePageSchema).min(1),
    printedPages: z.array(PositivePageSchema),
    regions: z.array(SourceRegionSchema).min(1).optional(),
  })
  .superRefine((source, context) => {
    if (new Set(source.pdfPages).size !== source.pdfPages.length) {
      context.addIssue({
        code: 'custom',
        path: ['pdfPages'],
        message: 'PDF page references must be unique',
      });
    }
    if (new Set(source.printedPages).size !== source.printedPages.length) {
      context.addIssue({
        code: 'custom',
        path: ['printedPages'],
        message: 'Printed page references must be unique',
      });
    }
    for (const [index, region] of (source.regions ?? []).entries()) {
      if (!source.pdfPages.includes(region.pdfPage)) {
        context.addIssue({
          code: 'custom',
          path: ['regions', index, 'pdfPage'],
          message: 'Region PDF page must appear in pdfPages',
        });
      }
      if (
        region.printedPage !== undefined &&
        !source.printedPages.includes(region.printedPage)
      ) {
        context.addIssue({
          code: 'custom',
          path: ['regions', index, 'printedPage'],
          message: 'Region printed page must appear in printedPages',
        });
      }
    }
  });

export type SourceRef = z.infer<typeof SourceRefSchema>;
