import { z } from 'zod';

import { AudioRefSchema } from './audio';
import { LessonBlockSchema } from './blocks';
import { NonEmptyTextSchema, SourceRefSchema } from './common';
import { ReviewMetadataSchema } from './review';

export const LearningTargetSchema = z.strictObject({
  id: z.string().regex(/^target-[a-z0-9]+(?:-[a-z0-9]+)*$/),
  kind: z.enum(['grapheme', 'syllable', 'reading', 'writing', 'numeral']),
  value: NonEmptyTextSchema,
  audio: AudioRefSchema.optional(),
});

export const LessonSchema = z.strictObject({
  id: z.string().regex(/^lesson-[a-z0-9]+(?:-[a-z0-9]+)*$/),
  lessonNumber: z.number().int().min(1).max(56),
  title: NonEmptyTextSchema.optional(),
  targets: z.array(LearningTargetSchema).min(1),
  source: SourceRefSchema,
  blocks: z.array(LessonBlockSchema).min(1),
  review: ReviewMetadataSchema,
});

export type LearningTarget = z.infer<typeof LearningTargetSchema>;
export type Lesson = z.infer<typeof LessonSchema>;
