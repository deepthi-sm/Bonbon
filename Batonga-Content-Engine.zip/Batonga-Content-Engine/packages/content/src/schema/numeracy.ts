import { z } from 'zod';

import {
  IllustrationBlockSchema,
  InstructionListBlockSchema,
  NumeralDisplayBlockSchema,
  SectionTextBlockSchema,
  WritingPracticeBlockSchema,
} from './blocks';
import { NonEmptyTextSchema, SourceRefSchema, StableIdSchema } from './common';
import { ReviewMetadataSchema } from './review';

export const NumeracyContentBlockSchema = z.discriminatedUnion('type', [
  NumeralDisplayBlockSchema,
  InstructionListBlockSchema,
  IllustrationBlockSchema,
  WritingPracticeBlockSchema,
  SectionTextBlockSchema,
]);

export const NumeracyUnitSchema = z.strictObject({
  id: z.string().regex(/^numeracy-unit-[a-z0-9]+(?:-[a-z0-9]+)*$/),
  number: z.number().int().min(0).max(9),
  numeral: NonEmptyTextSchema,
  word: NonEmptyTextSchema,
  source: SourceRefSchema,
  blocks: z.array(NumeracyContentBlockSchema).min(1),
  review: ReviewMetadataSchema,
});

export const NumeracyCurriculumSchema = z.strictObject({
  id: StableIdSchema,
  title: NonEmptyTextSchema,
  overview: z.array(SectionTextBlockSchema),
  units: z.array(NumeracyUnitSchema),
});

export type NumeracyContentBlock = z.infer<typeof NumeracyContentBlockSchema>;
export type NumeracyUnit = z.infer<typeof NumeracyUnitSchema>;
export type NumeracyCurriculum = z.infer<typeof NumeracyCurriculumSchema>;
