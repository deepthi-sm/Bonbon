import { z } from 'zod';

import { NonEmptyTextSchema, SourceRefSchema, StableIdSchema } from './common';

export const ReviewIssueTypeSchema = z.enum([
  'suspected_source_issue',
  'transcription_uncertainty',
  'layout_uncertainty',
  'asset_uncertainty',
]);

export const ReviewIssueStatusSchema = z.enum([
  'pending',
  'confirmed_source',
  'approved_correction',
]);

export const ReviewIssueSchema = z
  .strictObject({
    id: StableIdSchema,
    type: ReviewIssueTypeSchema,
    status: ReviewIssueStatusSchema,
    source: SourceRefSchema,
    observedContent: NonEmptyTextSchema,
    note: NonEmptyTextSchema.optional(),
    decisionNote: NonEmptyTextSchema.optional(),
  })
  .superRefine((issue, context) => {
    if (issue.status === 'approved_correction' && !issue.decisionNote) {
      context.addIssue({
        code: 'custom',
        path: ['decisionNote'],
        message: 'An approved correction requires a human decision note',
      });
    }
  });

export const TranscriptionReviewStateSchema = z.enum([
  'unreviewed',
  'reviewed',
  'needs_review',
]);
export const AssetReviewStateSchema = z.enum([
  'not_required',
  'unreviewed',
  'reviewed',
  'needs_review',
]);

export const ReviewMetadataSchema = z
  .strictObject({
    transcription: TranscriptionReviewStateSchema,
    assets: AssetReviewStateSchema,
    issueIds: z.array(StableIdSchema),
  })
  .superRefine((review, context) => {
    if (
      (review.transcription === 'needs_review' ||
        review.assets === 'needs_review') &&
      review.issueIds.length === 0
    ) {
      context.addIssue({
        code: 'custom',
        path: ['issueIds'],
        message:
          'Content marked needs_review must reference at least one review issue',
      });
    }
  });

export type ReviewIssue = z.infer<typeof ReviewIssueSchema>;
export type ReviewMetadata = z.infer<typeof ReviewMetadataSchema>;
