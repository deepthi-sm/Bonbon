import { existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import type { ContentAsset } from '../schema/assets';
import { ContentAssetSchema } from '../schema/assets';
import type { BatongaBook } from '../schema/book';
import { BatongaBookSchema } from '../schema/book';
import type { LessonBlock, TextItem } from '../schema/blocks';
import type { ReviewIssue } from '../schema/review';
import { ReviewIssueSchema } from '../schema/review';

export interface ContentBundle {
  book: BatongaBook;
  assets: ContentAsset[];
  reviewIssues: ReviewIssue[];
}

export type ValidationMode = 'fixture' | 'full';

const DEFAULT_PACKAGE_ROOT = fileURLToPath(new URL('../../', import.meta.url));

export class ContentValidationError extends Error {
  constructor(readonly problems: readonly string[]) {
    super(
      `Content validation failed:\n${problems.map((problem) => `- ${problem}`).join('\n')}`,
    );
    this.name = 'ContentValidationError';
  }
}

function addUnique(
  seen: Map<string, string>,
  id: string,
  location: string,
  problems: string[],
): void {
  const previous = seen.get(id);
  if (previous) {
    problems.push(
      `Duplicate identity "${id}" at ${location}; first seen at ${previous}`,
    );
    return;
  }
  seen.set(id, location);
}

function textItemsForBlock(block: LessonBlock): TextItem[] {
  switch (block.type) {
    case 'syllable_drill':
    case 'word_list':
    case 'sentence_list':
    case 'instruction_list':
    case 'writing_practice':
      return block.items;
    case 'illustration':
      return block.caption ? [block.caption] : [];
    case 'handwriting_demo':
      return block.examples;
    case 'numeral_display':
      return block.word ? [block.word] : [];
    case 'section_text':
      return block.paragraphs;
    case 'reading_passage':
    case 'dialogue':
    case 'grapheme':
      return [];
  }
}

export function validateContentBundle(
  input: unknown,
  options: { mode?: ValidationMode; packageRoot?: string } = {},
): ContentBundle {
  const mode = options.mode ?? 'fixture';
  const packageRoot = options.packageRoot ?? DEFAULT_PACKAGE_ROOT;
  const raw = input as {
    book?: unknown;
    assets?: unknown;
    reviewIssues?: unknown;
  };
  const book = BatongaBookSchema.parse(raw.book);
  const assets = ContentAssetSchema.array().parse(raw.assets);
  const reviewIssues = ReviewIssueSchema.array().parse(raw.reviewIssues);
  const problems: string[] = [];
  const identities = new Map<string, string>();
  const lessonNumbers = new Map<number, string>();
  const numeracyNumbers = new Map<number, string>();
  const allBlocks: { block: LessonBlock; location: string }[] = [];

  const registerBlock = (block: LessonBlock, location: string): void => {
    allBlocks.push({ block, location });
    addUnique(identities, block.id, `${location} block`, problems);
    for (const item of textItemsForBlock(block)) {
      addUnique(identities, item.id, `${location}/${block.id}`, problems);
    }
    if (block.type === 'reading_passage') {
      for (const segment of block.segments) {
        addUnique(
          identities,
          segment.id,
          `${location}/${block.id} passage segment`,
          problems,
        );
        if (segment.type === 'dialogue') {
          for (const turn of segment.turns) {
            addUnique(
              identities,
              turn.id,
              `${location}/${block.id} dialogue turn`,
              problems,
            );
          }
        }
      }
    }
    if (block.type === 'dialogue') {
      for (const turn of block.turns) {
        addUnique(
          identities,
          turn.id,
          `${location}/${block.id} dialogue turn`,
          problems,
        );
      }
    }
  };

  for (const lesson of book.literacy.lessons) {
    addUnique(identities, lesson.id, `lesson ${lesson.lessonNumber}`, problems);
    const priorLesson = lessonNumbers.get(lesson.lessonNumber);
    if (priorLesson) {
      problems.push(
        `Lesson number ${lesson.lessonNumber} is shared by ${priorLesson} and ${lesson.id}`,
      );
    } else {
      lessonNumbers.set(lesson.lessonNumber, lesson.id);
    }

    for (const target of lesson.targets) {
      addUnique(identities, target.id, `${lesson.id} target`, problems);
    }
    for (const block of lesson.blocks) {
      registerBlock(block, lesson.id);
    }
  }

  const memberships = new Map<number, string>();
  for (const section of book.literacy.sections) {
    addUnique(identities, section.id, 'literacy section', problems);
    for (const number of section.lessonNumbers) {
      if (!lessonNumbers.has(number)) {
        problems.push(
          `Section ${section.id} references missing lesson ${number}`,
        );
      }
      const previousSection = memberships.get(number);
      if (previousSection) {
        problems.push(
          `Lesson ${number} belongs to both ${previousSection} and ${section.id}`,
        );
      } else {
        memberships.set(number, section.id);
      }
    }
  }
  for (const number of lessonNumbers.keys()) {
    if (!memberships.has(number)) {
      problems.push(`Lesson ${number} is not assigned to a literacy section`);
    }
  }

  for (const material of book.literacy.referenceMaterials) {
    addUnique(
      identities,
      material.id,
      `literacy reference material ${material.type}`,
      problems,
    );
    for (const entry of material.entries) {
      addUnique(
        identities,
        entry.id,
        `literacy reference material ${material.id}`,
        problems,
      );
    }
  }

  if (mode === 'full') {
    const expected = Array.from({ length: 56 }, (_, index) => index + 1);
    const actual = [...lessonNumbers.keys()].sort(
      (left, right) => left - right,
    );
    if (
      actual.length !== expected.length ||
      actual.some((number, index) => number !== expected[index])
    ) {
      problems.push(
        'Full-corpus mode requires literacy lessons numbered exactly 1 through 56',
      );
    }
  }

  for (const unit of book.numeracy.units) {
    addUnique(identities, unit.id, `numeracy unit ${unit.number}`, problems);
    const priorUnit = numeracyNumbers.get(unit.number);
    if (priorUnit) {
      problems.push(
        `Numeracy unit number ${unit.number} is shared by ${priorUnit} and ${unit.id}`,
      );
    } else {
      numeracyNumbers.set(unit.number, unit.id);
    }
    for (const block of unit.blocks) {
      registerBlock(block, unit.id);
    }
  }
  if (mode === 'full') {
    const expected = Array.from({ length: 10 }, (_, index) => index);
    const actual = [...numeracyNumbers.keys()].sort(
      (left, right) => left - right,
    );
    if (
      actual.length !== expected.length ||
      actual.some((number, index) => number !== expected[index])
    ) {
      problems.push(
        'Full-corpus mode requires numeracy units numbered exactly 0 through 9',
      );
    }
  }
  for (const block of book.numeracy.overview) {
    registerBlock(block, `${book.numeracy.id} overview`);
  }
  for (const item of book.frontMatter.items) {
    addUnique(identities, item.id, `front matter ${item.type}`, problems);
    for (const block of item.blocks) {
      registerBlock(block, `front matter ${item.id}`);
    }
  }

  const assetById = new Map<string, ContentAsset>();
  const availableAssets = new Set<string>();
  for (const asset of assets) {
    addUnique(identities, asset.id, 'asset registry', problems);
    assetById.set(asset.id, asset);
    if (asset.status === 'available' && asset.path) {
      availableAssets.add(asset.id);
      const resolved = path.resolve(packageRoot, asset.path);
      const assetBoundary = `${path.resolve(packageRoot, 'assets')}${path.sep}`;
      const extension = path.extname(asset.path).toLowerCase();
      if (!resolved.startsWith(assetBoundary)) {
        problems.push(`Asset ${asset.id} resolves outside the asset tree`);
      } else if (!['.png', '.webp', '.svg'].includes(extension)) {
        problems.push(
          `Available asset ${asset.id} uses unsupported format ${extension || '(none)'}`,
        );
      } else if (!existsSync(resolved)) {
        problems.push(
          `Available asset ${asset.id} does not exist at ${asset.path}`,
        );
      } else {
        const file = statSync(resolved);
        if (!file.isFile() || file.size === 0) {
          problems.push(
            `Available asset ${asset.id} must point to a non-empty file`,
          );
        }
      }
    }
  }

  const referencedAssetIds = new Set<string>();
  for (const { block, location } of allBlocks) {
    if (block.type === 'illustration') {
      referencedAssetIds.add(block.assetId);
      const asset = assetById.get(block.assetId);
      if (!asset || asset.kind !== 'image') {
        problems.push(
          `${location}/${block.id} references unknown image asset ${block.assetId}`,
        );
      }
    }
    if (block.type === 'handwriting_demo') {
      for (const assetId of block.glyphAssetIds ?? []) {
        referencedAssetIds.add(assetId);
        const asset = assetById.get(assetId);
        if (!asset || asset.kind !== 'glyph') {
          problems.push(
            `${location}/${block.id} references unknown glyph asset ${assetId}`,
          );
        }
      }
    }
  }
  for (const assetId of availableAssets) {
    if (!referencedAssetIds.has(assetId)) {
      problems.push(`Available asset ${assetId} is not referenced by content`);
    }
  }

  const issueIds = new Set<string>();
  for (const issue of reviewIssues) {
    if (issueIds.has(issue.id)) {
      problems.push(`Duplicate review issue ${issue.id}`);
    }
    issueIds.add(issue.id);
  }
  for (const lesson of book.literacy.lessons) {
    for (const issueId of lesson.review.issueIds) {
      if (!issueIds.has(issueId)) {
        problems.push(
          `${lesson.id} references unknown review issue ${issueId}`,
        );
      }
    }
  }
  for (const unit of book.numeracy.units) {
    for (const issueId of unit.review.issueIds) {
      if (!issueIds.has(issueId)) {
        problems.push(`${unit.id} references unknown review issue ${issueId}`);
      }
    }
  }
  for (const material of book.literacy.referenceMaterials) {
    for (const issueId of material.review.issueIds) {
      if (!issueIds.has(issueId)) {
        problems.push(
          `${material.id} references unknown review issue ${issueId}`,
        );
      }
    }
  }
  for (const item of book.frontMatter.items) {
    for (const issueId of item.review.issueIds) {
      if (!issueIds.has(issueId)) {
        problems.push(`${item.id} references unknown review issue ${issueId}`);
      }
    }
  }

  if (problems.length > 0) {
    throw new ContentValidationError(problems);
  }

  return { book, assets, reviewIssues };
}
