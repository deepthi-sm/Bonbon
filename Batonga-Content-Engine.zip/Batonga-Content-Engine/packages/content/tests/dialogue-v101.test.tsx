import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';

import {
  BlockRenderer,
  DialogueBlockSchema,
  DialogueTurnSchema,
  ReadingPassageBlockSchema,
} from '@core/content';

describe('Batonga Content Schema v1.0.1 dialogue turns', () => {
  it('accepts a labelled dialogue turn', () => {
    expect(
      DialogueTurnSchema.safeParse({
        id: 'turn-labelled',
        speaker: 'Awa',
        text: 'Bonjour.',
      }).success,
    ).toBe(true);
  });

  it('accepts an unlabelled dialogue turn', () => {
    expect(
      DialogueTurnSchema.safeParse({
        id: 'turn-unlabelled',
        text: 'Bonjour.',
        audio: { key: 'fr:dialogue:bonjour', fallbackText: 'Bonjour.' },
      }).success,
    ).toBe(true);
  });

  it('rejects an empty speaker', () => {
    expect(
      DialogueTurnSchema.safeParse({
        id: 'turn-empty-speaker',
        speaker: '',
        text: 'Bonjour.',
      }).success,
    ).toBe(false);
  });

  it('remains strict and rejects unknown dialogue-turn fields', () => {
    expect(
      DialogueTurnSchema.safeParse({
        id: 'turn-unknown-field',
        text: 'Bonjour.',
        marker: '-',
      }).success,
    ).toBe(false);
  });

  it('supports narration, unlabelled dialogue, narration ordering', () => {
    const passage = ReadingPassageBlockSchema.parse({
      id: 'mixed-reading-passage',
      type: 'reading_passage',
      preserveSourceOrder: true,
      segments: [
        { id: 'opening-narration', type: 'narration', text: 'Avant.' },
        {
          id: 'unlabelled-dialogue',
          type: 'dialogue',
          turns: [{ id: 'middle-turn', text: 'Bonjour.' }],
        },
        { id: 'closing-narration', type: 'narration', text: 'Après.' },
      ],
    });

    expect(passage.segments.map((segment) => segment.type)).toEqual([
      'narration',
      'dialogue',
      'narration',
    ]);
    expect(passage.segments[1]).toMatchObject({
      type: 'dialogue',
      turns: [{ text: 'Bonjour.' }],
    });
  });

  it('renders an unlabelled turn without inventing a speaker', () => {
    const block = DialogueBlockSchema.parse({
      id: 'unlabelled-dialogue-block',
      type: 'dialogue',
      preserveSourceOrder: true,
      turns: [{ id: 'unlabelled-render-turn', text: 'Bonjour.' }],
    });

    const html = renderToStaticMarkup(<BlockRenderer block={block} />);
    expect(html).toContain('data-dialogue-turn="unlabelled"');
    expect(html).toContain('Bonjour.');
    expect(html).not.toContain('<strong>');
    expect(html).not.toContain('undefined');
  });

  it('continues to render a labelled turn with its source speaker', () => {
    const block = DialogueBlockSchema.parse({
      id: 'labelled-dialogue-block',
      type: 'dialogue',
      preserveSourceOrder: true,
      turns: [{ id: 'labelled-render-turn', speaker: 'Awa', text: 'Bonjour.' }],
    });

    const html = renderToStaticMarkup(<BlockRenderer block={block} />);
    expect(html).toContain('data-dialogue-turn="labelled"');
    expect(html).toContain('<strong>Awa</strong>');
    expect(html).toContain('Bonjour.');
  });
});
