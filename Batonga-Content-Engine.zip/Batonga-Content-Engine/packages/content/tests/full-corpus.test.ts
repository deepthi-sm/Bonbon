import { describe, expect, it } from 'vitest';

import { contentAssets, contentRepository } from '@core/content';
import { reviewIssues } from '../src/review-data';
import { validateContentBundle } from '../src/validation/validate-content';

describe('complete Batonga corpus', () => {
  it('contains and retrieves exactly Lessons 01–56', () => {
    const expected = Array.from({ length: 56 }, (_, index) => index + 1);
    expect(
      contentRepository.getLessons().map((lesson) => lesson.lessonNumber),
    ).toEqual(expected);
    expect(
      new Set(contentRepository.getLessons().map((lesson) => lesson.id)).size,
    ).toBe(56);
    for (const number of expected) {
      expect(contentRepository.getLessonByNumber(number)?.lessonNumber).toBe(
        number,
      );
    }
  });

  it('contains and retrieves exactly Numeracy Units 0–9', () => {
    const expected = Array.from({ length: 10 }, (_, index) => index);
    expect(
      contentRepository.getNumeracyUnits().map((unit) => unit.number),
    ).toEqual(expected);
    for (const number of expected) {
      expect(contentRepository.getNumeracyUnit(number)?.number).toBe(number);
    }
  });

  it('passes strict full-corpus validation', () => {
    expect(() =>
      validateContentBundle(
        {
          book: contentRepository.getBook(),
          assets: contentAssets,
          reviewIssues,
        },
        { mode: 'full' },
      ),
    ).not.toThrow();
  });
});
