import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';

import { ContentDemo } from '../../../components/dev/content-demo';

describe('Batonga integration demo', () => {
  it('renders repository-backed literacy and numeracy fixtures', () => {
    const html = renderToStaticMarkup(<ContentDemo />);

    expect(html).toContain('data-lesson-id="lesson-01"');
    expect(html).toContain('data-lesson-id="lesson-06"');
    expect(html).toContain('data-lesson-id="lesson-42"');
    expect(html).toContain('data-lesson-id="lesson-56"');
    expect(html).toContain('data-numeracy-unit="0"');
    expect(html).toContain('data-numeracy-unit="9"');
    expect(html).toContain('data-asset-status="available"');
    expect(html).toContain('data:image/png;base64,');
    expect(html).toContain('data-dialogue-turn="unlabelled"');
  });
});
