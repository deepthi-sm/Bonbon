import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';

interface InventoryLesson {
  lessonNumber: number;
  pdfPages: number[];
  printedPages: number[];
  status: 'fixture' | 'digitised' | 'needs_review';
}

interface LiteracyInventory {
  lessons: InventoryLesson[];
}

const inventory = JSON.parse(
  readFileSync(
    fileURLToPath(
      new URL('../inventory/literacy-source-map.json', import.meta.url),
    ),
    'utf8',
  ),
) as LiteracyInventory;

describe('literacy source inventory', () => {
  it('records each digitised lesson number exactly once', () => {
    expect(inventory.lessons.map((lesson) => lesson.lessonNumber)).toEqual(
      Array.from({ length: 56 }, (_, index) => index + 1),
    );
    for (const lesson of inventory.lessons) {
      expect(lesson.pdfPages.length).toBeGreaterThan(0);
      expect(lesson.printedPages.length).toBeGreaterThan(0);
      expect(['fixture', 'digitised', 'needs_review']).toContain(lesson.status);
    }
  });

  it('agrees with the complete repository corpus', () => {
    expect(
      inventory.lessons.every((lesson) => lesson.status !== 'needs_review'),
    ).toBe(true);
    expect(inventory.lessons.map((lesson) => lesson.lessonNumber)).toEqual(
      Array.from({ length: 56 }, (_, index) => index + 1),
    );
  });
});
