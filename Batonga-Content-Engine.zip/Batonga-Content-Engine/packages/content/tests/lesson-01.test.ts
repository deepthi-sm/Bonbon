import { describe, expect, it } from 'vitest';

import { batongaBook } from '@core/content';

describe('Lesson 01 source fixture', () => {
  const lesson = batongaBook.literacy.lessons[0];

  it('preserves the verified target, anchor and source page provenance', () => {
    expect(lesson.targets.map((target) => target.value)).toEqual(['i']);
    expect(lesson.source).toEqual({ pdfPages: [7, 8], printedPages: [6, 7] });
    const illustration = lesson.blocks.find(
      (block) => block.type === 'illustration',
    );
    expect(illustration?.caption?.text).toBe('un épi');
  });

  it('preserves vocabulary and writing order while representing print and cursive semantically', () => {
    const vocabulary = lesson.blocks.find(
      (block) => block.type === 'word_list',
    );
    const writing = lesson.blocks.find(
      (block) => block.type === 'writing_practice',
    );

    expect(vocabulary?.items.map((item) => item.text)).toEqual([
      'fil',
      'image',
      'canari',
      'farine',
      'rivière',
      'fini',
      'mil',
    ]);
    expect(
      vocabulary?.items.every((item) =>
        item.representations?.includes('cursive'),
      ),
    ).toBe(true);
    expect(writing?.items.map((item) => item.text)).toEqual([
      'i',
      'I',
      'mil',
      'image',
    ]);
  });
});
