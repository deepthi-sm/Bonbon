import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';

import { LessonPlayer, LessonSchema, contentRepository } from '@core/content';

describe('Lesson 42 fixture', () => {
  const lesson = contentRepository.getLessonByNumber(42);

  it('is valid and maps the visually verified source page', () => {
    expect(lesson).toBeDefined();
    expect(LessonSchema.safeParse(lesson).success).toBe(true);
    expect(lesson?.source).toEqual({ pdfPages: [73], printedPages: [72] });
    expect(lesson?.targets.map((target) => target.value)).toEqual([
      'oir',
      'oire',
    ]);
  });

  it('preserves narration, unlabelled dialogue, narration source order', () => {
    const passage = lesson?.blocks.find(
      (block) => block.type === 'reading_passage',
    );
    expect(passage?.type).toBe('reading_passage');
    if (!passage || passage.type !== 'reading_passage') {
      throw new Error('Lesson 42 reading passage is missing');
    }

    expect(passage.title).toBe('Une histoire');
    expect(passage.segments.map((segment) => segment.type)).toEqual([
      'narration',
      'dialogue',
      'narration',
    ]);
    const dialogue = passage.segments[1];
    expect(dialogue?.type).toBe('dialogue');
    if (!dialogue || dialogue.type !== 'dialogue') {
      throw new Error('Lesson 42 dialogue segment is missing');
    }

    expect(dialogue.turns).toHaveLength(2);
    for (const turn of dialogue.turns) {
      expect(turn.speaker).toBeUndefined();
      expect(turn.text.startsWith('-')).toBe(false);
      expect(turn.audio?.fallbackText.startsWith('-')).toBe(false);
    }
  });

  it('renders through the generic LessonPlayer without fabricating speakers', () => {
    if (!lesson) throw new Error('Lesson 42 fixture is missing');

    const html = renderToStaticMarkup(<LessonPlayer lesson={lesson} />);
    expect(html).toContain('Une histoire');
    expect(html).toContain('data-dialogue-turn="unlabelled"');
    expect(html).not.toContain('undefined');
    expect(html).not.toContain('Victoire</strong>');
    expect(html).not.toContain('Maman</strong>');
  });
});
