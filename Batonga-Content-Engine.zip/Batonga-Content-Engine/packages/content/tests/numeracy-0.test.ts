import { describe, expect, it } from 'vitest';

import {
  NumeracyUnitSchema,
  contentRepository,
  type WritingPracticeBlock,
} from '@core/content';

describe('Numeracy Unit 0 fixture', () => {
  const unit = contentRepository.getNumeracyUnit(0);

  it('is a valid separate numeracy unit mapped to the source pages', () => {
    expect(unit).toBeDefined();
    expect(NumeracyUnitSchema.safeParse(unit).success).toBe(true);
    expect(unit).toMatchObject({
      id: 'numeracy-unit-0',
      number: 0,
      numeral: '0',
      word: 'zéro',
      source: { pdfPages: [91, 92], printedPages: [88, 89] },
    });
    expect(contentRepository.getLessonByNumber(57)).toBeUndefined();
  });

  it('represents the zero display and print/cursive writing practice', () => {
    expect(unit?.blocks[0]).toMatchObject({
      type: 'numeral_display',
      value: 0,
      display: '0',
      word: { text: 'zéro' },
    });
    const writing = unit?.blocks.find(
      (block): block is WritingPracticeBlock =>
        block.type === 'writing_practice',
    );
    expect(writing?.items.map((item) => item.text)).toEqual(['0', 'zéro']);
    expect(writing?.representations).toEqual(['print', 'cursive']);
  });
});
