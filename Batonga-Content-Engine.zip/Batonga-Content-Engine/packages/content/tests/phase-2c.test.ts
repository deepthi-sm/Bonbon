import { describe, expect, it } from 'vitest';

import {
  AlphabetChartSchema,
  CONTENT_SCHEMA_VERSION,
  FrontMatterItemSchema,
  SourceRefSchema,
  batongaBook,
  contentRepository,
} from '@core/content';

describe('Schema v1.0.2 provenance', () => {
  it('identifies the released schema version', () => {
    expect(CONTENT_SCHEMA_VERSION).toBe('1.0.2');
  });

  it('accepts confirmed unnumbered and ordinary numbered source pages', () => {
    expect(
      SourceRefSchema.safeParse({ pdfPages: [3], printedPages: [] }).success,
    ).toBe(true);
    expect(
      SourceRefSchema.safeParse({ pdfPages: [7], printedPages: [6] }).success,
    ).toBe(true);
  });

  it('keeps physical PDF pages mandatory and non-empty', () => {
    expect(
      SourceRefSchema.safeParse({ pdfPages: [], printedPages: [] }).success,
    ).toBe(false);
    expect(SourceRefSchema.safeParse({ printedPages: [] }).success).toBe(false);
  });

  it('keeps the printedPages field mandatory', () => {
    expect(SourceRefSchema.safeParse({ pdfPages: [3] }).success).toBe(false);
  });

  it('accepts front matter on a confirmed unnumbered source page', () => {
    const frontCover = batongaBook.frontMatter.items.find(
      (item) => item.id === 'front-cover',
    );
    expect(frontCover?.source).toEqual({ pdfPages: [1], printedPages: [] });
    expect(FrontMatterItemSchema.safeParse(frontCover).success).toBe(true);
  });
});

describe('literacy reference materials', () => {
  it('models the source alphabet chart without creating a lesson', () => {
    const chart = batongaBook.literacy.referenceMaterials[0];
    expect(AlphabetChartSchema.safeParse(chart).success).toBe(true);
    expect(chart?.id).toBe('alphabet-chart');
    expect(chart?.source).toEqual({ pdfPages: [5], printedPages: [4] });
    expect(chart?.entries).toHaveLength(26);
    expect(chart?.entries.map((entry) => entry.grapheme).join('')).toBe(
      'abcdefghijklmnopqrstuvwxyz',
    );
    expect(
      chart?.entries.filter((entry) => entry.category === 'vowel'),
    ).toHaveLength(6);
    expect(
      chart?.entries.filter((entry) => entry.category === 'consonant'),
    ).toHaveLength(20);
    expect(contentRepository.getLessons()).toHaveLength(56);
  });

  it('rejects unknown alphabet-chart fields strictly', () => {
    const chart = structuredClone(
      batongaBook.literacy.referenceMaterials[0],
    ) as unknown as Record<string, unknown>;
    chart.pageLayout = 'two rows';
    expect(AlphabetChartSchema.safeParse(chart).success).toBe(false);

    const strictEntry = structuredClone(
      batongaBook.literacy.referenceMaterials[0]!.entries[0],
    ) as unknown as Record<string, unknown>;
    strictEntry.color = 'pink';
    expect(
      AlphabetChartSchema.safeParse({
        ...batongaBook.literacy.referenceMaterials[0],
        entries: [strictEntry],
      }).success,
    ).toBe(false);
  });

  it('retrieves reference materials through the immutable repository', () => {
    expect(contentRepository.getLiteracyReferenceMaterials()).toHaveLength(1);
    expect(
      contentRepository.getLiteracyReferenceMaterial('alphabet-chart'),
    ).toBe(contentRepository.getLiteracyReferenceMaterials()[0]);
    expect(
      contentRepository.getLiteracyReferenceMaterial('missing-material'),
    ).toBeUndefined();
    expect(
      Object.isFrozen(contentRepository.getLiteracyReferenceMaterials()),
    ).toBe(true);
    expect(
      Object.isFrozen(
        contentRepository.getLiteracyReferenceMaterial('alphabet-chart'),
      ),
    ).toBe(true);
    expect(
      Object.isFrozen(
        contentRepository.getLiteracyReferenceMaterial('alphabet-chart')
          ?.entries,
      ),
    ).toBe(true);
  });
});
