import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';

import { LessonPlayer, LessonSchema } from '@core/content';

describe('LessonPlayer', () => {
  it('dispatches every supported lesson block to a renderer', () => {
    const source = { pdfPages: [1], printedPages: [1] };
    const item = (id: string, text = id) => ({ id, text });
    const lesson = LessonSchema.parse({
      id: 'lesson-renderers',
      lessonNumber: 1,
      targets: [
        { id: 'target-reading', kind: 'reading', value: 'renderer coverage' },
      ],
      source,
      review: { transcription: 'reviewed', assets: 'reviewed', issueIds: [] },
      blocks: [
        {
          id: 'block-grapheme',
          type: 'grapheme',
          grapheme: 'i',
          representations: ['print'],
        },
        {
          id: 'block-syllables',
          type: 'syllable_drill',
          preserveSourceOrder: true,
          items: [item('syllable-mi', 'mi')],
        },
        {
          id: 'block-words',
          type: 'word_list',
          preserveSourceOrder: true,
          items: [item('word-mil', 'mil')],
        },
        {
          id: 'block-sentences',
          type: 'sentence_list',
          preserveSourceOrder: true,
          items: [item('sentence-one', 'Une phrase.')],
        },
        {
          id: 'block-reading',
          type: 'reading_passage',
          preserveSourceOrder: true,
          segments: [
            { id: 'narration-one', type: 'narration', text: 'Texte.' },
          ],
        },
        {
          id: 'block-dialogue',
          type: 'dialogue',
          preserveSourceOrder: true,
          turns: [{ id: 'dialogue-turn-one', speaker: 'A', text: 'Bonjour.' }],
        },
        {
          id: 'block-instructions',
          type: 'instruction_list',
          preserveSourceOrder: true,
          items: [item('instruction-one', 'Lis.')],
        },
        {
          id: 'block-illustration',
          type: 'illustration',
          assetId: 'unresolved-picture',
        },
        {
          id: 'block-handwriting',
          type: 'handwriting_demo',
          representations: ['cursive'],
          examples: [item('handwriting-i', 'i')],
        },
        {
          id: 'block-writing',
          type: 'writing_practice',
          preserveSourceOrder: true,
          representations: ['print'],
          items: [item('writing-i', 'i')],
        },
        {
          id: 'block-numeral',
          type: 'numeral_display',
          value: 1,
          display: '1',
        },
        {
          id: 'block-section',
          type: 'section_text',
          preserveSourceOrder: true,
          paragraphs: [item('paragraph-one', 'Introduction.')],
        },
      ],
    });

    const html = renderToStaticMarkup(
      <LessonPlayer lesson={lesson} assets={[]} />,
    );
    for (const type of [
      'grapheme',
      'syllable_drill',
      'word_list',
      'sentence_list',
      'reading_passage',
      'dialogue',
      'instruction_list',
      'illustration',
      'handwriting_demo',
      'writing_practice',
      'numeral_display',
      'section_text',
    ]) {
      expect(html).toContain(`data-block-type="${type}"`);
    }
  });
});
