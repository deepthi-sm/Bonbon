import { describe, expect, it } from 'vitest';

import {
  batongaBook,
  contentRepository,
  createContentRepository,
} from '@core/content';

describe('contentRepository', () => {
  it('retrieves the book, sections, lesson and front matter deterministically', () => {
    expect(contentRepository.getBook().id).toBe('batonga-syllabary');
    expect(contentRepository.getLiteracySections()).toHaveLength(1);
    expect(contentRepository.getLesson('lesson-01')?.lessonNumber).toBe(1);
    expect(contentRepository.getLessonByNumber(1)?.id).toBe('lesson-01');
    expect(contentRepository.getLessonByNumber(42)?.id).toBe('lesson-42');
    expect(contentRepository.getFrontMatter().items).toHaveLength(8);
    expect(contentRepository.getFrontMatter().items[0]?.id).toBe('front-cover');
    expect(contentRepository.getFrontMatter().items.at(-1)?.id).toBe(
      'back-cover-contact',
    );
    expect(
      contentRepository.getLessons().map((lesson) => lesson.lessonNumber),
    ).toEqual(Array.from({ length: 56 }, (_, index) => index + 1));
    expect(contentRepository.getNumeracyUnits()).toHaveLength(10);
    expect(contentRepository.getNumeracyUnit(0)?.word).toBe('zéro');
    expect(contentRepository.getNumeracyUnit(9)?.word).toBe('neuf');
  });

  it('navigates deterministically across the complete corpus', () => {
    expect(contentRepository.getNextLesson('lesson-01')?.id).toBe('lesson-02');
    expect(contentRepository.getPreviousLesson('lesson-42')?.id).toBe(
      'lesson-41',
    );
    expect(contentRepository.getNextLesson('lesson-42')?.id).toBe('lesson-43');
    expect(contentRepository.getNextLesson('lesson-56')).toBeUndefined();
  });

  it('provides ordered previous and next lesson navigation', () => {
    const book = structuredClone(batongaBook);
    const lessons = [book.literacy.lessons[0]!, book.literacy.lessons[1]!];
    book.literacy.lessons = lessons;
    book.literacy.sections[0]!.lessonNumbers = [1, 2];
    const repository = createContentRepository(book);

    expect(repository.getNextLesson('lesson-01')?.id).toBe('lesson-02');
    expect(repository.getPreviousLesson('lesson-02')?.id).toBe('lesson-01');
    expect(repository.getPreviousLesson('lesson-01')).toBeUndefined();
    expect(repository.getNextLesson('lesson-02')).toBeUndefined();
  });

  it('returns a runtime-immutable content graph', () => {
    expect(Object.isFrozen(contentRepository.getBook())).toBe(true);
    expect(Object.isFrozen(contentRepository.getLessons())).toBe(true);
    expect(
      Object.isFrozen(contentRepository.getLesson('lesson-01')?.blocks),
    ).toBe(true);
  });
});
