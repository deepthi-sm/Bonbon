import { describe, expect, it } from 'vitest';

import {
  GlyphAssetSchema,
  ImageAssetSchema,
  LessonSchema,
  NumeracyUnitSchema,
  NumeralDisplayBlockSchema,
  ReviewIssueSchema,
  TextItemSchema,
  batongaBook,
} from '@core/content';

const source = { pdfPages: [7], printedPages: [6] };

function numeracyUnit(number: number) {
  return {
    id: 'numeracy-unit-test',
    number,
    numeral: String(number),
    word: 'fixture',
    source,
    blocks: [
      {
        id: 'numeral-test',
        type: 'numeral_display',
        value: 0,
        display: '0',
      },
    ],
    review: {
      transcription: 'reviewed',
      assets: 'not_required',
      issueIds: [],
    },
  };
}

function numeralDisplay(value: number) {
  return {
    id: 'numeral-boundary',
    type: 'numeral_display',
    value,
    display: String(value),
  };
}

describe('strict persisted content contracts', () => {
  it('rejects a Lesson containing learningObjectives', () => {
    expect(
      LessonSchema.safeParse({
        ...structuredClone(batongaBook.literacy.lessons[0]),
        learningObjectives: ['Generated objective'],
      }).success,
    ).toBe(false);
  });

  it('rejects a ReviewIssue containing correctedText', () => {
    expect(
      ReviewIssueSchema.safeParse({
        id: 'suspected-copy-error',
        type: 'suspected_source_issue',
        status: 'pending',
        source,
        observedContent: 'Observed source text',
        correctedText: 'Silent correction',
      }).success,
    ).toBe(false);
  });

  it('rejects progress on a nested lesson block', () => {
    const lesson = structuredClone(batongaBook.literacy.lessons[0]);
    const firstBlock = lesson.blocks[0] as unknown as Record<string, unknown>;
    firstBlock.progress = 100;

    expect(LessonSchema.safeParse(lesson).success).toBe(false);
  });

  it('rejects unknown fields on a nested TextItem contract', () => {
    const lesson = structuredClone(batongaBook.literacy.lessons[0]);
    const vocabulary = lesson.blocks.find(
      (block) => block.type === 'word_list',
    );
    if (!vocabulary || vocabulary.type !== 'word_list') {
      throw new Error('Lesson 01 word list fixture is missing');
    }
    const firstItem = vocabulary.items[0] as unknown as Record<string, unknown>;
    firstItem.hiddenMetadata = true;

    expect(LessonSchema.safeParse(lesson).success).toBe(false);
    expect(
      TextItemSchema.safeParse({
        id: 'word-test',
        text: 'test',
        hiddenMetadata: true,
      }).success,
    ).toBe(false);
  });
});

describe('numeracy 0–9 boundaries', () => {
  it.each([0, 9])('accepts NumeracyUnit.number %s', (number) => {
    expect(NumeracyUnitSchema.safeParse(numeracyUnit(number)).success).toBe(
      true,
    );
  });

  it.each([-1, 10])('rejects NumeracyUnit.number %s', (number) => {
    expect(NumeracyUnitSchema.safeParse(numeracyUnit(number)).success).toBe(
      false,
    );
  });

  it.each([0, 9])('accepts NumeralDisplayBlock.value %s', (value) => {
    expect(
      NumeralDisplayBlockSchema.safeParse(numeralDisplay(value)).success,
    ).toBe(true);
  });

  it.each([-1, 10])('rejects NumeralDisplayBlock.value %s', (value) => {
    expect(
      NumeralDisplayBlockSchema.safeParse(numeralDisplay(value)).success,
    ).toBe(false);
  });
});

describe('asset state invariants', () => {
  const image = {
    id: 'image-test',
    kind: 'image',
    alt: 'Source illustration',
    source,
  };
  const glyph = {
    id: 'glyph-test',
    kind: 'glyph',
    character: 'i',
    representation: 'cursive',
    source,
  };

  it('accepts valid available and unresolved image states', () => {
    expect(
      ImageAssetSchema.safeParse({
        ...image,
        status: 'available',
        path: 'assets/test.png',
      }).success,
    ).toBe(true);
    expect(
      ImageAssetSchema.safeParse({ ...image, status: 'unresolved' }).success,
    ).toBe(true);
  });

  it('rejects invalid available and unresolved image states', () => {
    expect(
      ImageAssetSchema.safeParse({ ...image, status: 'available' }).success,
    ).toBe(false);
    expect(
      ImageAssetSchema.safeParse({
        ...image,
        status: 'unresolved',
        path: 'assets/test.png',
      }).success,
    ).toBe(false);
  });

  it('accepts valid available and unresolved glyph states', () => {
    expect(
      GlyphAssetSchema.safeParse({
        ...glyph,
        status: 'available',
        path: 'assets/test.svg',
      }).success,
    ).toBe(true);
    expect(
      GlyphAssetSchema.safeParse({ ...glyph, status: 'unresolved' }).success,
    ).toBe(true);
  });

  it('rejects invalid available and unresolved glyph states', () => {
    expect(
      GlyphAssetSchema.safeParse({ ...glyph, status: 'available' }).success,
    ).toBe(false);
    expect(
      GlyphAssetSchema.safeParse({
        ...glyph,
        status: 'unresolved',
        path: 'assets/test.svg',
      }).success,
    ).toBe(false);
  });
});
