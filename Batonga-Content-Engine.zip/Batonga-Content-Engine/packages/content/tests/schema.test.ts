import { describe, expect, it } from 'vitest';

import {
  AudioRefSchema,
  LessonSchema,
  NumeracyUnitSchema,
  ReviewIssueSchema,
  SourceRefSchema,
  batongaBook,
} from '@core/content';

describe('content schemas', () => {
  it('accepts the verified Lesson 01 fixture', () => {
    expect(LessonSchema.parse(batongaBook.literacy.lessons[0]).id).toBe(
      'lesson-01',
    );
  });

  it('rejects an unsupported block discriminator', () => {
    const lesson = structuredClone(
      batongaBook.literacy.lessons[0],
    ) as unknown as Record<string, unknown>;
    lesson.blocks = [{ id: 'unsupported-block', type: 'quiz' }];
    expect(LessonSchema.safeParse(lesson).success).toBe(false);
  });

  it('rejects invalid source page references', () => {
    expect(
      SourceRefSchema.safeParse({ pdfPages: [0], printedPages: [6] }).success,
    ).toBe(false);
    expect(
      SourceRefSchema.safeParse({
        pdfPages: [7],
        printedPages: [6],
        regions: [{ pdfPage: 8, printedPage: 6, side: 'left' }],
      }).success,
    ).toBe(false);
  });

  it('requires a human decision note for an approved correction', () => {
    const result = ReviewIssueSchema.safeParse({
      id: 'source-correction',
      type: 'suspected_source_issue',
      status: 'approved_correction',
      source: { pdfPages: [7], printedPages: [6] },
      observedContent: 'Contenu source observé.',
      note: 'A human must decide this change.',
    });
    expect(result.success).toBe(false);
  });

  it('validates reusable audio key syntax without requiring audio files', () => {
    expect(
      AudioRefSchema.safeParse({ key: 'fr:word:fil', fallbackText: 'fil' })
        .success,
    ).toBe(true);
    expect(
      AudioRefSchema.safeParse({ key: 'fil', fallbackText: 'fil' }).success,
    ).toBe(false);
  });

  it('models numeracy as a separate content unit rather than a later lesson', () => {
    const result = NumeracyUnitSchema.safeParse({
      id: 'numeracy-unit-01',
      number: 1,
      numeral: '1',
      word: 'un',
      source: { pdfPages: [80], printedPages: [79] },
      blocks: [
        {
          id: 'numeral-one',
          type: 'numeral_display',
          value: 1,
          display: '1',
        },
      ],
      review: {
        transcription: 'reviewed',
        assets: 'not_required',
        issueIds: [],
      },
    });
    expect(result.success).toBe(true);
    expect(
      LessonSchema.safeParse({
        ...batongaBook.literacy.lessons[0],
        id: 'lesson-57',
        lessonNumber: 57,
      }).success,
    ).toBe(false);
  });
});
