import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';

import { describe, expect, it } from 'vitest';

import { batongaBook, type ContentAsset, contentAssets } from '@core/content';
import { reviewIssues } from '../src/review-data';
import {
  ContentValidationError,
  validateContentBundle,
} from '../src/validation/validate-content';

describe('content bundle validation', () => {
  it('accepts the complete corpus in fixture mode', () => {
    expect(
      validateContentBundle({
        book: batongaBook,
        assets: contentAssets,
        reviewIssues,
      }),
    ).toMatchObject({ book: { id: 'batonga-syllabary' } });
  });

  it('rejects duplicate lesson identities', () => {
    const book = structuredClone(batongaBook);
    book.literacy.lessons.push(structuredClone(book.literacy.lessons[0]!));
    book.literacy.sections[0]!.lessonNumbers.push(1);

    expect(() =>
      validateContentBundle({ book, assets: contentAssets, reviewIssues }),
    ).toThrow(ContentValidationError);
  });

  it('accepts the complete literacy and numeracy ranges in full-corpus mode', () => {
    expect(() =>
      validateContentBundle(
        { book: batongaBook, assets: contentAssets, reviewIssues },
        { mode: 'full' },
      ),
    ).not.toThrow();
  });

  it('rejects an incomplete literacy range in full-corpus mode', () => {
    const book = structuredClone(batongaBook);
    book.literacy.lessons.pop();
    book.literacy.sections[0]!.lessonNumbers.pop();

    expect(() =>
      validateContentBundle(
        { book, assets: contentAssets, reviewIssues },
        { mode: 'full' },
      ),
    ).toThrow(/1 through 56/);
  });

  it('rejects an incomplete numeracy range in full-corpus mode', () => {
    const book = structuredClone(batongaBook);
    book.numeracy.units.pop();

    expect(() =>
      validateContentBundle(
        { book, assets: contentAssets, reviewIssues },
        { mode: 'full' },
      ),
    ).toThrow(/0 through 9/);
  });

  it('rejects needs-review metadata that references no registered issue', () => {
    const book = structuredClone(batongaBook);
    book.literacy.lessons[0]!.review.issueIds = ['missing-review-issue'];

    expect(() =>
      validateContentBundle({ book, assets: contentAssets, reviewIssues }),
    ).toThrow(/unknown review issue/);
  });

  it.each([
    ['unsupported format', 'assets/pilot.txt', 'x', /unsupported format/],
    ['empty file', 'assets/pilot.png', '', /non-empty file/],
  ])('rejects an available asset with %s', (_, assetPath, contents, error) => {
    const packageRoot = mkdtempSync(path.join(tmpdir(), 'batonga-assets-'));
    try {
      mkdirSync(path.join(packageRoot, 'assets'), { recursive: true });
      writeFileSync(path.join(packageRoot, assetPath), contents);
      const assets: ContentAsset[] = structuredClone(contentAssets).map(
        (asset) => {
          const unresolved: ContentAsset = {
            ...asset,
            status: 'unresolved',
          };
          delete unresolved.path;
          return unresolved;
        },
      );
      assets[0] = {
        ...assets[0]!,
        status: 'available',
        path: assetPath,
      };

      expect(() =>
        validateContentBundle(
          { book: batongaBook, assets, reviewIssues },
          { packageRoot },
        ),
      ).toThrow(error);
    } finally {
      rmSync(packageRoot, { recursive: true, force: true });
    }
  });
});
