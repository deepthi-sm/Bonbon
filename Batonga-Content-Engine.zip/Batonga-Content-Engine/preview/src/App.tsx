import { useState, type ReactNode } from 'react';

import {
  BlockRenderer,
  LessonPlayer,
  type ContentAsset,
  type SourceRef,
  contentRepository,
} from '@core/content';

import { previewAssets } from './asset-adapter';

type View = 'literacy' | 'numeracy' | 'front-matter' | 'reference' | 'assets';

const views: Array<{ id: View; label: string; count: number }> = [
  { id: 'literacy', label: 'Literacy lessons', count: 56 },
  { id: 'numeracy', label: 'Numeracy units', count: 10 },
  { id: 'front-matter', label: 'Front matter', count: 8 },
  { id: 'reference', label: 'Alphabet chart', count: 1 },
  { id: 'assets', label: 'Asset gallery', count: 68 },
];

function Panel({ children }: { children: ReactNode }) {
  return <section className="panel">{children}</section>;
}

function Provenance({ source }: { source: SourceRef }) {
  return (
    <dl className="provenance">
      <div>
        <dt>PDF pages</dt>
        <dd>{source.pdfPages.join(', ')}</dd>
      </div>
      <div>
        <dt>Printed pages</dt>
        <dd>
          {source.printedPages.length > 0
            ? source.printedPages.join(', ')
            : 'unnumbered'}
        </dd>
      </div>
    </dl>
  );
}

function Chips({ values }: { values: readonly string[] }) {
  return (
    <div className="chips">
      {values.map((value, index) => (
        <code key={`${value}-${index}`}>{value}</code>
      ))}
    </div>
  );
}

function LiteracyView() {
  const lessons = contentRepository.getLessons();
  const [number, setNumber] = useState(1);
  const lesson = contentRepository.getLessonByNumber(number) ?? lessons[0];
  const previous = contentRepository.getPreviousLesson(lesson.id);
  const next = contentRepository.getNextLesson(lesson.id);
  const assetIds = lesson.blocks.flatMap((block) => {
    if (block.type === 'illustration') return [block.assetId];
    if (block.type === 'handwriting_demo') return block.glyphAssetIds ?? [];
    return [];
  });

  return (
    <div className="view-stack">
      <Panel>
        <div className="control-row">
          <label>
            <span>Lesson selector</span>
            <select
              value={lesson.lessonNumber}
              onChange={(event) => setNumber(Number(event.target.value))}
            >
              {lessons.map((candidate) => (
                <option key={candidate.id} value={candidate.lessonNumber}>
                  Lesson {String(candidate.lessonNumber).padStart(2, '0')}
                  {candidate.title ? ` — ${candidate.title}` : ''}
                </option>
              ))}
            </select>
          </label>
          <div className="pager">
            <button
              type="button"
              disabled={!previous}
              onClick={() => previous && setNumber(previous.lessonNumber)}
            >
              ← Previous
            </button>
            <button
              type="button"
              disabled={!next}
              onClick={() => next && setNumber(next.lessonNumber)}
            >
              Next →
            </button>
          </div>
        </div>
      </Panel>

      <Panel>
        <div className="metadata">
          <p className="eyebrow">
            Lesson {String(lesson.lessonNumber).padStart(2, '0')}
          </p>
          <h2>{lesson.title ?? 'Untitled lesson'}</h2>
          <Provenance source={lesson.source} />
          <div>
            <h3>Targets</h3>
            <ul className="target-list">
              {lesson.targets.map((target) => (
                <li key={target.id}>
                  <span>{target.kind}</span> {target.value}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3>Block types</h3>
            <Chips values={lesson.blocks.map((block) => block.type)} />
          </div>
          {assetIds.length > 0 ? (
            <div>
              <h3>Asset IDs</h3>
              <Chips values={assetIds} />
            </div>
          ) : null}
        </div>
      </Panel>

      <Panel>
        <div className="rendered-content">
          <LessonPlayer lesson={lesson} assets={previewAssets} />
        </div>
      </Panel>
    </div>
  );
}

function NumeracyView() {
  const units = contentRepository.getNumeracyUnits();
  const [number, setNumber] = useState(0);
  const unit = contentRepository.getNumeracyUnit(number) ?? units[0];

  return (
    <div className="view-stack">
      <Panel>
        <label>
          <span>Numeracy unit selector</span>
          <select
            value={unit.number}
            onChange={(event) => setNumber(Number(event.target.value))}
          >
            {units.map((candidate) => (
              <option key={candidate.id} value={candidate.number}>
                Unit {candidate.number} — {candidate.word}
              </option>
            ))}
          </select>
        </label>
      </Panel>
      <Panel>
        <article className="metadata" data-numeracy-unit={unit.number}>
          <p className="eyebrow">Numeracy Unit {unit.number}</p>
          <h2>
            {unit.numeral} · {unit.word}
          </h2>
          <Provenance source={unit.source} />
          <div>
            <h3>Block types</h3>
            <Chips values={unit.blocks.map((block) => block.type)} />
          </div>
          <div className="rendered-content">
            {unit.blocks.map((block) => (
              <BlockRenderer
                key={block.id}
                block={block}
                assets={previewAssets}
              />
            ))}
          </div>
        </article>
      </Panel>
    </div>
  );
}

function FrontMatterView() {
  const items = contentRepository.getFrontMatter().items;
  const [id, setId] = useState(items[0].id);
  const item = items.find((candidate) => candidate.id === id) ?? items[0];
  const title = 'title' in item ? item.title : undefined;
  const attribution = 'attribution' in item ? item.attribution : undefined;

  return (
    <div className="view-stack">
      <Panel>
        <label>
          <span>Front-matter selector</span>
          <select
            value={item.id}
            onChange={(event) => setId(event.target.value)}
          >
            {items.map((candidate, index) => (
              <option key={candidate.id} value={candidate.id}>
                {index + 1}. {candidate.id}
              </option>
            ))}
          </select>
        </label>
      </Panel>
      <Panel>
        <article className="metadata" data-front-matter-id={item.id}>
          <p className="eyebrow">{item.type}</p>
          <h2>{title ?? item.id}</h2>
          {attribution ? <p className="attribution">{attribution}</p> : null}
          <Provenance source={item.source} />
          <div className="rendered-content">
            {item.blocks.length > 0 ? (
              item.blocks.map((block) => (
                <BlockRenderer
                  key={block.id}
                  block={block}
                  assets={previewAssets}
                />
              ))
            ) : (
              <p className="empty-note">
                This item contains title and provenance metadata only.
              </p>
            )}
          </div>
        </article>
      </Panel>
    </div>
  );
}

function ReferenceView() {
  const materials = contentRepository.getLiteracyReferenceMaterials();
  const material = materials[0];

  return (
    <Panel>
      <article className="metadata" data-reference-material-id={material.id}>
        <p className="eyebrow">Literacy reference material</p>
        <h2>{material.title}</h2>
        <Provenance source={material.source} />
        <div className="alphabet-grid">
          {material.entries.map((entry, index) => (
            <article key={entry.id} className="alphabet-card">
              <p>
                {index + 1}. {entry.category}
              </p>
              <strong>
                {entry.grapheme} {entry.uppercase}
              </strong>
              <small>{entry.representations.join(' · ')}</small>
            </article>
          ))}
        </div>
      </article>
    </Panel>
  );
}

function AssetCard({ asset }: { asset: ContentAsset }) {
  const label = asset.kind === 'image' ? asset.alt : asset.character;
  return (
    <article className="asset-card" data-asset-id={asset.id}>
      <div className="asset-image">
        {asset.status === 'available' && asset.path ? (
          <img src={asset.path} alt={label} />
        ) : (
          <span>Unavailable</span>
        )}
      </div>
      <div className="asset-details">
        <code>{asset.id}</code>
        <p>{label}</p>
        <Provenance source={asset.source} />
      </div>
    </article>
  );
}

function AssetGalleryView() {
  const illustrations = previewAssets.filter((asset) => asset.kind === 'image');
  const glyphs = previewAssets.filter((asset) => asset.kind === 'glyph');

  return (
    <div className="view-stack">
      <Panel>
        <p className="eyebrow">Production assets</p>
        <h2>68/68 available</h2>
        <p>24 illustrations · 44 cursive glyphs</p>
      </Panel>
      <section>
        <div className="section-heading">
          <h2>Illustrations</h2>
          <span>{illustrations.length}</span>
        </div>
        <div className="asset-grid illustrations">
          {illustrations.map((asset) => (
            <AssetCard key={asset.id} asset={asset} />
          ))}
        </div>
      </section>
      <section>
        <div className="section-heading">
          <h2>Cursive glyphs</h2>
          <span>{glyphs.length}</span>
        </div>
        <div className="asset-grid glyphs">
          {glyphs.map((asset) => (
            <AssetCard key={asset.id} asset={asset} />
          ))}
        </div>
      </section>
    </div>
  );
}

export function App() {
  const [view, setView] = useState<View>('literacy');

  return (
    <main>
      <header className="hero">
        <div>
          <p className="eyebrow">Standalone QA preview</p>
          <h1>Batonga Content Engine</h1>
          <p>
            Inspect the complete source-faithful literacy and numeracy corpus,
            its front matter, alphabet chart, and all production assets.
          </p>
        </div>
        <div className="status-card">
          <strong>Dev A complete</strong>
          <span>Schema v1.0.2</span>
          <span>Checkpoint a91b9da</span>
        </div>
      </header>

      <nav className="primary-nav" aria-label="Preview sections">
        {views.map((candidate) => (
          <button
            type="button"
            key={candidate.id}
            aria-pressed={view === candidate.id}
            onClick={() => setView(candidate.id)}
          >
            {candidate.label}
            <span>{candidate.count}</span>
          </button>
        ))}
      </nav>

      {view === 'literacy' ? <LiteracyView /> : null}
      {view === 'numeracy' ? <NumeracyView /> : null}
      {view === 'front-matter' ? <FrontMatterView /> : null}
      {view === 'reference' ? <ReferenceView /> : null}
      {view === 'assets' ? <AssetGalleryView /> : null}
    </main>
  );
}
