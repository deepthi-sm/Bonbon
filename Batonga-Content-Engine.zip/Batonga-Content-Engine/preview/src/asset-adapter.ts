import { type ContentAsset, contentAssets } from '@core/content';

const assetUrls = import.meta.glob<string>(
  '../../packages/content/assets/**/*.{png,webp,svg}',
  {
    eager: true,
    query: '?url',
    import: 'default',
  },
);

export const previewAssets: readonly ContentAsset[] = contentAssets.map(
  (asset) => {
    if (asset.status !== 'available' || !asset.path) return asset;

    const modulePath = `../../packages/content/${asset.path}`;
    const url = assetUrls[modulePath];
    if (!url) {
      throw new Error(
        `Missing bundled asset URL for ${asset.id}: ${modulePath}`,
      );
    }

    return { ...asset, path: url };
  },
);
