import { fileURLToPath, URL } from 'node:url';

import { defineConfig } from 'vite';

export default defineConfig({
  root: fileURLToPath(new URL('./preview', import.meta.url)),
  publicDir: false,
  resolve: {
    alias: {
      '@core/content': fileURLToPath(
        new URL('./packages/content/src/index.ts', import.meta.url),
      ),
    },
  },
  build: {
    outDir: fileURLToPath(new URL('./dist', import.meta.url)),
    emptyOutDir: true,
  },
});
