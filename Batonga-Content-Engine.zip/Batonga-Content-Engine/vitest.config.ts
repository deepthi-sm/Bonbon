import { fileURLToPath, URL } from 'node:url';

import { defineConfig } from 'vitest/config';

export default defineConfig({
  resolve: {
    alias: {
      '@core/content': fileURLToPath(
        new URL('./packages/content/src/index.ts', import.meta.url),
      ),
    },
  },
  test: {
    include: [
      'packages/content/tests/**/*.test.ts',
      'packages/content/tests/**/*.test.tsx',
      'preview/**/*.test.ts',
      'preview/**/*.test.tsx',
    ],
    environment: 'node',
  },
});
